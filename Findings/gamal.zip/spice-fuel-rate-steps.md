---
title: "In 99 of 147 SPICE flames (67%) the fuel rate was changed during the burn"
author: mohamed-gamal
date: 2026-11-15
investigations: [PSI-107]
pillars: [detection]           # CHECK: judgement
habitats: [space-station]
claim: "In the PSI-107 experimental table, 99 of 147 flames (67%) have more than one HC fuel rate between ignition and flame-off."
evidence:
  - kind: table
    ref: PSI-107_Experimental_table_Spice.csv
    note: "435 records after removing 34 exact duplicates, grouped by GMT day and ignition time into 147 flames"
  - kind: computation
    ref: scripts/spice_prepare.py    # CHECK: set to the real repo path
    note: "Builds spice_flames.csv with the minimum and maximum HC fuel rate per flame"
confidence: high
si_assisted: true
---

## What we did
We cleaned the SPICE experimental table (duplicates removed, times standardised) and defined a flame as one ignition on one GMT day. For each flame we compared the lowest and highest HC fuel rate recorded between ignition and flame-off.

## What we found
99 of the 147 flames show a change in fuel rate; 101 flames have more than one table record. The remaining flames have a single fuel rate.

## Why it matters
For anyone modelling smoke point from this table, one flame is not one test condition: the fuel rate steps within a flame, so the condition at which smoke appears has to be matched to the right step. This needs the smoke-point result files, which are not in the table. Soot output of gas flames is relevant to smoke production for detection.

## Caveats
Flames are grouped by ignition time, and 12 flames with no usable ignition time were each kept as their own single-record flame, so the true share could differ slightly. We think the fuel rate is stepped to find the smoke point, but that is our reading of the pattern and is not confirmed by the PSI-107 documents. The smoke-point and flame-length files were not read.
