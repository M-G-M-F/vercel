---
title: "Air directly above the SLICE nozzle runs at only about 20% of the peak velocity beside it"
author: mohamed-gamal
date: 2026-11-15
investigations: [PSI-106]
pillars: [prevention]          # CHECK: judgement
habitats: [space-station]
claim: "At 4 mm above the SLICE nozzle, the air velocity at the nozzle centre is 19% to 23% of the peak off-centre velocity at all seven fan readings (for example 10.9 cm/s against 56.8 cm/s at fan reading 98)."
evidence:
  - kind: table
    ref: PSI-106 SLICE_BoundaryCondition.xlsx, sheet "Variation near Nozzle", X direction, 4 mm above nozzle
    note: "Measured velocity at 12 positions from -19 to 11 mm for each fan reading; units not stated in the sheet, assumed cm/s"
  - kind: computation
    ref: scripts/slice_prepare.py    # CHECK: set to the real repo path
    note: "Tidies the sheet and gives the centre (x = 0) and maximum velocity per fan reading; the ratio does not depend on the unit"
confidence: high
si_assisted: true
---

## What we did
We reshaped the SLICE boundary-condition workbook into one table (463 measurements) and took the 2009 X-direction scan at 4 mm above the nozzle, which has seven fan readings (56 to 139). For each fan reading we compared the velocity at x = 0 with the largest velocity in the scan.

## What we found
The centre velocity is 19% to 23% of the scan maximum at every fan reading.

| Fan reading | Centre (cm/s) | Maximum (cm/s) | Centre / maximum |
|---|---|---|---|
| 56 | 3.5 | 17.4 | 0.20 |
| 98 | 10.9 | 56.8 | 0.19 |
| 139 | 18.6 | 81.7 | 0.23 |

## Why it matters
The airflow a flame sits in is not the uniform coflow the fan setting suggests. Close to the nozzle there is a wake, so a flammability or smoke model that assumes a flat velocity profile would overestimate the air reaching the flame base. Fire-safety tests on the ISS use this duct, so local velocity matters, not only the duct setting.

## Caveats
Only the 4 mm plane and the X-direction scan from the 2009 measurements are used. The sheet does not state units (velocities assumed cm/s), though the ratio does not depend on them. We did not check how the profile changes with distance above the nozzle beyond the 1 mm and 4 mm planes. This is an airflow measurement, not a flame result.
