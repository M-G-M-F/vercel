from pathlib import Path
import pandas as pd,re
ROOT=Path(__file__).resolve().parent
out=ROOT/'output/analysis/T1'; d=pd.read_csv(out/'dashboard_runs.csv',keep_default_na=False)
cols=['investigation_id','run_id','source_file','source_row','x_secondary_row','date_raw','date_excel_raw','date_corrected','gmt_day_raw','gmt_day','date_quality_flag','date_evidence','date_alternative']
assert len(d)==250 and d.run_id.is_unique and d.date_corrected.is_monotonic_increasing
assert (pd.to_datetime(d.date_corrected).dt.dayofyear==d.gmt_day).all()
for k,g in d.groupby('investigation_id'):
 assert g.date_corrected.is_monotonic_increasing
 folder=next(p for p in out.glob(k+'_*') if p.is_dir()); g[cols].to_csv(folder/'tables/date_audit.csv',index=False)
 g[g.date_quality_flag!='consistent'][cols].to_csv(folder/'tables/date_review.csv',index=False)
 g[cols].to_csv(out/f'{k}_chronology.csv',index=False)
d[d.date_quality_flag!='consistent'][cols].to_csv(out/'date_review.csv',index=False)
summary='Date audit v4: 250 runs. Eight date/GMT conflicts adjudicated using CSV, as-run workbook, 2013 actual/video date columns and neighbouring tests. Test 93: Apr 26 / GMT 116 (high confidence). Test 111: May 17 / GMT 137 provisionally; tests 112-116: May 30 / GMT 150 provisionally; O10: July 22 / GMT 203 provisionally. Seven choices require original video/log confirmation. Raw values and alternatives retained. T9/T18 inferred 2014 pending confirmation. Derived GMT agrees with selected dates, not proof of actual event date. Dates sorted ascending with source-order ties. FAQ distinguishes display dates from actual dates; no blanket offset. Original sources unchanged.' 
(out/'DATE_VALIDATION.md').write_text(summary+'\n',encoding='utf-8')
for name in ['HANDOFF.md','VALIDATION.md']:
 p=out/name;p.write_text(p.read_text()+'\n\n'+summary+'\n')
raw=(ROOT/'deep_analysis_original.txt').read_text(encoding='utf-8'); lookup=d.set_index('run_id').to_dict('index'); chunks=re.split(r'(?=^### \[CHUNK )',raw,flags=re.M); found=set(); result=[]
for chunk in chunks:
 m=re.search(r'^### \[CHUNK .*?\| run (.+)$',chunk,re.M)
 if m and m.group(1).strip() in lookup:
  rid=m.group(1).strip();v=lookup[rid];found.add(rid); lines=chunk.splitlines(keepends=True); lines.insert(2,'[CALC date audit] '+ '; '.join(f'{k}: {v[k]}' for k in ['date_raw','date_excel_raw','date_corrected','gmt_day_raw','gmt_day','date_quality_flag','date_evidence','date_alternative'])+'\n');chunk=''.join(lines)
 result.append(chunk)
assert len(found)==250,len(found)
# Reorder only contiguous run chunks, preserving thematic sections and source IDs.
i=0
while i<len(result):
 if not re.match(r'### \[CHUNK T1-(25|26)-RUN-',result[i]): i+=1;continue
 j=i+1
 while j<len(result) and re.match(r'### \[CHUNK T1-(25|26)-RUN-',result[j]):j+=1
 result[i:j]=sorted(result[i:j],key=lambda c:lookup[re.search(r'\| run (.+)',c).group(1).strip()]['date_corrected']);i=j
result.insert(2,'### [CHUNK T1-DATE-AUDIT] Date quality and chronology\n[CALC/FLAG] '+summary+'\n\n')
(out/'Amr_BASS_Deep_Analysis_v4.txt').write_text(''.join(result),encoding='utf-8')

clean=re.sub(r'^#+[ \t]*','',(out/'Amr_BASS_Deep_Analysis_v4.txt').read_text(encoding='utf-8'),flags=re.M).replace('Split on lines beginning ### [CHUNK','Split on lines beginning [CHUNK')
(out/'Amr_BASS_Deep_Analysis_v4_clean.txt').write_text(clean,encoding='utf-8')
