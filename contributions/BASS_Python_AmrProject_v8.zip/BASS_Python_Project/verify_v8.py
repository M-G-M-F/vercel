"""Scientific source audit: unit evidence, metadata field status, and explicit date confidence.
Runs after finalize_v7; does not change observed numeric values or invent run dates.
"""
from pathlib import Path
import json, re, hashlib
import pandas as pd
import openpyxl
R=Path(__file__).resolve().parent; T=R/'output/analysis/T1'; E=T/'extra'
read=lambda p:pd.read_csv(p,dtype=str,keep_default_na=False)
D=read(T/'dashboard_runs_enriched.csv'); B=D[D.investigation_id=='PSI-26']; w=openpyxl.load_workbook(R/'data/BASS%20test%20matrix.xlsx'); s=w['as run matrix']
assert len(B)==121 and s['AA3'].value=='O2 % by volume' and s['K3'].value=='Air display'
assert pd.to_numeric(B.raw_o2_by_volume).between(0,1).all()
assert ((pd.to_numeric(B.raw_o2_by_volume)*100-pd.to_numeric(B.oxygen_pct)).abs()<1e-8).all()
formula_rows=[int(n) for n in B.source_row if s[f'AA{n}'].data_type=='f']; assert len(formula_rows)==67
assert s['AA46'].value=='=164.23/750.1' and s['AB46'].value=='=750.1/760'
for n,v in [(4,'10 cm/s'),(31,'9 cm/s'),(33,'9.75 cm/s'),(34,'10 cm/s')]:assert v in s[f'AD{n}'].value
assert B.x_air_parse_status.value_counts().to_dict()=={'scalar':46,'numeric_sequence':41,'qualified_or_mixed':22,'missing':12}
P25='https://psi.nasa.gov/physci/repo/data/investigations/PSI-25'; P26='https://psi.nasa.gov/physci/repo/data/investigations/PSI-26'; N26='https://ntrs.nasa.gov/api/citations/20140011099/downloads/20140011099.pdf'; N25='https://ntrs.nasa.gov/api/citations/20210011385/downloads/TM-20210011385.pdf'; GRC='https://www1.grc.nasa.gov/wp-content/uploads/BASS-Quad-Chart.pdf'; JUNE='https://www.nasa.gov/blogs/stationreport/2014/06/24/iss-daily-summary-report-06-24-14/'
unit='PSI-26 units: workbook as run matrix AA3 labels O2 by volume; all 121 stored values are fractions (0.159–0.22721983147); 67 formula cells, including AA46 =164.23/750.1, support the fraction representation. Convert once by multiplying by 100 to vol% (15.9–22.722). AB3 is pressure in atm. K3 Air display represents nominal duct air velocity in cm/s: K4=10,5 with U4 and AD4 explicit cm/s; K31=9,0 with AD31 ignition at 9 cm/s; K33=9.75,0 and K34=10,0 likewise match narrative units. NASA NTRS 20140011099, slide 2, identifies BASS forced airspeed in cm/s and ambient oxygen in percent. Keep fan settings and flow restrictors separate. 46 scalar and 41 numeric-list air display records are parsed; 22 qualified/mixed and 12 missing remain without exact parsed values. A display zero need not prove zero local flow. No single steady or extinction velocity is inferred. Source: '+N26
meta='Metadata audit: PSI-25 identity, DOI, CC0, research area, ISS, GRC, project dates 2010-01-01 to 2022-12-31 and release date 2022-12-31 match NASA PSI Version 4 (updated 2025-11-24). The supplied original PSI-25 ISA metadata also matches the study ID, title, DOI and release date. PSI-26 experiment title, ISS/MSG, GRC involvement and scientific scope are corroborated by NASA technical presentation and GRC project chart. PSI-26 live registry returned no readable content; DOI, CC0, project dates and registry-specific fields are retained from the supplied snapshot, not independently reverified. Both project periods are metadata, not run-date ranges. File counts, version-specific listings, publication lists and investigator-role labels are snapshot fields, not independently verified. Sources: '+P25+'; '+P26+'; '+N26+'; '+GRC
chron='Date audit: all 250 selected dates match derived day-of-year GMT. Nine run dates still lack independent exact-run verification: PSI-26 as-run 93 (planned test 38), 111 (109), 112 (79), 113 (80), 114 (75), 115 (53), 116 (53a); PSI-25 T9 and T18. For 93, workbook 2013 sheet row 23 gives April 26 actual date and April 27 displayed date, versus GMT 113; April 26 was scheduled, not independently documented for this test. For 111, adjacent as-run 109–110 share GMT 137 and May 17; NASA confirms a session May 17. For 112–116, GMT 150 plus the May 30 session supports May 30; source actual date is June 1. For T9/T18, the final NASA report Appendix A.6 itself repeats 2018; the 2014 GMT-year header, day 175, and NASA June 24, 2014 report describing two matching fabric tests support the 2014 correction, not an exact-run confirmation. O10 has individual run-table corroboration (A.5). Original video/log identifiers and time overlays are required to close the nine remaining exact-run evidence gaps. '+N25+'; '+JUNE
repls=[('unit unconfirmed; raw display only','cm/s nominal duct air display (workbook K/U/AD and NASA NTRS 20140011099); not local or steady velocity'),('PSI-26 airflow unit not independently verified','PSI-26 nominal air display in cm/s supported by workbook and NASA NTRS 20140011099'),('PSI-26 oxygen unit conversion is inferred','PSI-26 oxygen fraction conversion is supported by original workbook formulas and NASA BASS documentation'),('Oxygen fraction multiplied by 100; assumption pending confirmation.','Oxygen stored as a volume fraction; ×100 conversion to vol% verified against workbook formulas.'),('for PSI-26 the unit is unconfirmed','for PSI-26 cm/s is supported by workbook K/U/AD and NASA BASS documentation'),('PSI-26 unit unconfirmed','PSI-26 nominal duct air display in cm/s supported by workbook K/U/AD and NASA BASS documentation'),('Metadata is from a supplied snapshot, not independently refreshed.','Metadata core fields checked against NASA sources; remaining registry-only fields are retained as snapshot values (see metadata audit).'),('human review, scientific units and official citation confirmation pending','human review and some registry fields remain pending; PSI-26 oxygen and air-display units have source evidence'),('no standardized BASS airflow','PSI-26 also records nominal air display in cm/s (46 scalar and 41 numeric-list records); no standardized steady-state or extinction velocity'),('Nine provisional dates/year choices and the PSI-26 oxygen/airflow units need source confirmation. Live NASA metadata, original videos and human approval are not verified.','Nine date selections still lack exact-run corroboration; PSI-26 oxygen and nominal air-display units have workbook and NASA source support. PSI-25 core registry fields checked; PSI-26 live registry fields partly unverified. Original videos and human approval remain unavailable.')]
def update(s):
 for a,b in repls:s=s.replace(a,b)
 return s
# All output text and JSON (excluding immutable raw inputs and source logs).
for p in T.rglob('*'):
 if p.is_file() and p.suffix in ['.md','.txt','.json'] and p.name not in ['raw_hashes.json','si_log.md']:
  text=p.read_text(encoding='utf-8'); new=update(text)
  if new!=text:p.write_text(new,encoding='utf-8')
# Update published CSV fields and add unit evidence for downstream use.
for p in [T/'dashboard_runs.csv',T/'dashboard_runs_enriched.csv',T/'dashboard_runs_analysis_ready.csv',E/'run_features.csv',*T.glob('PSI-*/tables/*runs_clean.csv'),*T.glob('PSI-*/tables/run_features.csv')]:
 d=read(p); assert 'run_id' in d
 mask=d.run_id.str.startswith('PSI-26:')
 for c in ['notes','x_air_listed_unit_basis']:
  if c in d:d[c]=d[c].map(update)
 d['x_oxygen_unit_evidence']='PSI-25 calibrated initial/final O2 source columns in vol%'; d.loc[mask,'x_oxygen_unit_evidence']='PSI-26 workbook AA3/AA46 and 67 ratio formulas: fraction x100 to vol%'
 d['x_air_display_unit']='cm/s';d['x_air_display_unit_evidence']='PSI-25 FAQ: duct air velocity display in cm/s; instrument lag';d.loc[mask,'x_air_display_unit_evidence']='PSI-26 workbook K4/U4/AD4, K31/AD31, K33/AD33, K34/AD34; NASA NTRS 20140011099'
 # This unit is specific to Air display; generic flow_speed remains untouched.
 if p.name=='dashboard_runs_analysis_ready.csv':
  feats=D.set_index('run_id');
  for c in ['x_air_parse_status','x_air_listed_values_json','x_air_listed_count','x_air_listed_min','x_air_listed_max']: d[c]=d.run_id.map(feats[c])
 d.to_csv(p,index=False)
# Concise source audit, separated from the analytical view.
report='Morgan V8 — Scientific source verification\n\n'+meta+'\n\n'+unit+'\n\n'+chron+'\n\nChecks: 250 unique records; 121/129 run chunks; zero arithmetic Date/GMT mismatches. All four raw data hashes unchanged. No new date or measurement imputation.\n'
(T/'SCIENTIFIC_SOURCE_AUDIT.txt').write_text(report,encoding='utf-8')
for p in [T/'Amr_BASS_Deep_Analysis_v7_clean.txt',*T.glob('PSI-*/rag_corpus.txt')]:
 text=p.read_text(); append='\n[CHUNK T1-METADATA-V8] Metadata verification scope\n'+meta+'\n\n[CHUNK T1-DATE-VERIFICATION-V8] Date evidence and limits\n'+chron+'\n'
 if 'PSI-25_bass-ii' not in str(p):append+='\n[CHUNK T1-26-UNITS-V8] Source-supported units\n'+unit+'\n'
 p.write_text(text+append,encoding='utf-8')
 if p.name.startswith('Amr_'):p.rename(T/'Amr_BASS_Deep_Analysis_v8_clean.txt')
for name in ['references.md','HANDOFF.md','VALIDATION.md','DATE_VALIDATION.md']:
 p=T/name; p.write_text(p.read_text()+'\nV8 source verification: see SCIENTIFIC_SOURCE_AUDIT.txt. '+N26+'; '+P25+'; '+GRC+'\n',encoding='utf-8')
p=R/'README.md';p.write_text(update(p.read_text())+'\nV8 source verification: output/analysis/T1/SCIENTIFIC_SOURCE_AUDIT.txt documents unit evidence, metadata field scope and nine exact-run date evidence gaps.\n',encoding='utf-8')
assert len(D)==250 and D.run_id.is_unique and pd.to_datetime(D.date).dt.dayofyear.eq(D.gmt_day.astype(int)).all()
assert all(hashlib.sha256((R/'data'/n).read_bytes()).hexdigest()==h for n,h in json.loads((T/'raw_hashes.json').read_text()).items())
for p in T.glob('PSI-*/rag_corpus.txt'):
 k=p.parent.name[4:6];t=p.read_text();assert len(re.findall(r'^\[CHUNK T1-'+k+r'-RUN-',t,re.M))=={'25':129,'26':121}[k];assert 'unit unconfirmed; raw display only' not in t
print(report)
