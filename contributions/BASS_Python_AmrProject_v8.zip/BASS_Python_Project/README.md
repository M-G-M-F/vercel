# BASS / BASS-II — Morgan T1 V6

Python 3.10+ recommended. Open the project folder in VS Code or Cursor.

```sh
python -m pip install -r requirements.txt
python main.py
```

All four supplied raw tables and the metadata/FAQ are included. The pipeline writes to `output/analysis/T1/`. Source files are never overwritten.

Use `dashboard_runs.csv` for the V5-compatible view, `dashboard_runs_enriched.csv` for V6 features, and `PSI-25_bass-ii/rag_corpus.txt` and `PSI-26_bass/rag_corpus.txt` for dataset-specific retrieval. The combined V6 TXT is an alternative, not an additional corpus to ingest alongside both individual files. `deep_analysis_original.txt` is a historical input to the generator, not a final corpus.

Per-investigation run tables use the team schema (date columns now have `x_` prefixes). See `extra/FEATURE_DICTIONARY.md`, `extra/V6_CHANGES.md`, `extra/oxygen_sensitivity.csv`, `SELF_CHECK.md`, and `TEAM_SELF_CHECK.md`.

The supplied kit validator is bundled unchanged in `tools/`. V6 makes context-based material inference additive, screens negative/censored gas readings, and parses only complete numeric airflow strings. No safety threshold, validated outcome label, causal ranking, or ML model is claimed. Nine date selections still lack exact-run corroboration; PSI-26 oxygen and nominal air-display units have workbook and NASA source support. PSI-25 core registry fields checked; PSI-26 live registry fields partly unverified. Original videos and human approval remain unavailable. Retrieval questions are fixtures, not measured chatbot performance.

## V7 analytical delivery

Run `python main.py` to regenerate the full pipeline including final screening.
For dashboard ingestion use `output/analysis/T1/dashboard_runs_analysis_ready.csv` (one canonical analytical view, without legacy raw measurements). `date`/`gmt_day` are selected chronology values; consult `date_verification` and the separate date audit. Use `x_material_family_analysis` for the context-supported classification; older material summaries are keyword-only and remain for reproducibility. Final oxygen values lacking a defensible raw measurement pair are blank, not zero. Gas measurements with censoring or invalid numeric values have blank exact values and explicit statuses. `extra/measurement_quality_audit.csv`, `extra/material_classification_audit.csv`, `date_review.csv`, and original source files retain provenance. The published technical report was checked through its indexed table text; page screenshot retrieval failed because of the PDF size. The BASS sample-design PDF was visually checked. No original videos were inspected. RAG files use the selected date and screened values; exact source data remain available for audit.

V8 source verification: output/analysis/T1/SCIENTIFIC_SOURCE_AUDIT.txt documents unit evidence, metadata field scope and nine exact-run date evidence gaps.

V8 source verification: output/analysis/T1/SCIENTIFIC_SOURCE_AUDIT.txt documents unit evidence, metadata field scope and nine exact-run date evidence gaps.
