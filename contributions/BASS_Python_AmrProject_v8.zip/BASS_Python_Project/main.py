from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    args = ["--input", str(ROOT / "data"), "--output", str(ROOT / "output")]
    for script, extra in [("bass_pipeline_v2.py", []), ("bass_audit_v2.py", ["--metadata", str(ROOT / "metadata")])]:
        subprocess.run([sys.executable, str(ROOT / script), *args, *extra], check=True, cwd=ROOT)
    subprocess.run([sys.executable, str(ROOT / "date_report.py")], check=True, cwd=ROOT)
    subprocess.run([sys.executable, str(ROOT / "enhance.py")], check=True, cwd=ROOT)
    subprocess.run([sys.executable, str(ROOT / "improve_v6.py")], check=True, cwd=ROOT)
    subprocess.run([sys.executable, str(ROOT / "finalize_v7.py")], check=True, cwd=ROOT)
    subprocess.run([sys.executable, str(ROOT / "verify_v8.py")], check=True, cwd=ROOT)
    print("Completed. Results:", ROOT / "output" / "analysis" / "T1")

if __name__ == "__main__":
    main()
