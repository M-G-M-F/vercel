"""Conservative date reconciliation; original values are never overwritten."""
import pandas as pd
import re
from datetime import date

def parse(v):
    if pd.isna(v) or not str(v).strip(): return None
    s=str(v).strip().replace('`','').replace("'",'')
    try: return pd.Timestamp(s).date()
    except (ValueError, TypeError): return None

def reconcile(n,r,s):
    csv,xl=(r,s) if n==25 else (s,r)
    raw=csv.get('Date',''); xraw=next((v for k,v in xl.items() if k.startswith('Actual Date')),'')
    g=csv.get('GMT',''); a,b=parse(raw),parse(xraw); d=b or a; flags=[]
    if '`' in str(raw) or '`' in str(xraw): flags.append('format_normalized')
    if a and b and a!=b: flags.append('source_date_conflict')
    try: gd=int(g) if not pd.isna(g) and float(g)==int(g) else None
    except (ValueError,TypeError,OverflowError): gd=None
    header=next((k for k in xl if k.startswith('GMT')),'')
    start=str(xl.get('Approx Start Time ( with GMT)',''))
    if n==26 and d==date(2103,5,15) and gd==135 and re.search(r'13\s*[- ]\s*135',start):
        d=date(2013,5,15); flags.append('year_typo_corrected')
    if n==25 and d and d.year==2018 and header=='GMT 2014-' and gd==d.timetuple().tm_yday:
        d=d.replace(year=2014); flags.append('year_inferred_from_sheet_header')
    evidence=''; alternative=''
    if n==26 and gd is not None and d and d.year==2013:
        test=str(xl.get('As run test no.',''))
        if test=='93' and gd==113 and d==date(2013,4,26):
            flags.append('gmt_corrected_high_confidence'); evidence='2013 sheet row 23 actual/video dates Apr 26/27; rows 24-27 same session GMT 116; row 22 Apr 23 GMT 113.'; alternative='2013-04-23'
        elif test=='111' and gd==137 and d==date(2013,6,1):
            alternative=d.isoformat(); d=date(2013,5,17); flags.append('date_inferred_gmt_provisional'); evidence='2013 sheet row 41 conflicts internally; rows 38-40 GMT 137 May 17, same sample/igniter; row 40 same O2 and pressure. Actual/video June 1/2 could instead be correct.'
        elif test in ['112','113','114','115','116'] and gd==150 and d==date(2013,6,1):
            alternative=d.isoformat(); d=date(2013,5,30); flags.append('date_inferred_gmt_provisional'); evidence='2013 sheet rows 42-46 share GMT 150 with distinct start times; actual/video June 1/2 also repeated. GMT-derived May 30 selected provisionally, not independently verified.'
    if n==25 and str(csv.get('Test #','')).upper()=='O10' and gd==213 and d==date(2014,7,22):
        flags.append('gmt_inferred_provisional'); alternative='2014-08-01'; evidence='Olson row 14; row 23 O17 same July 22 GMT 203, similar rod and consecutive sample 211m; rows 19/25 Aug 1 GMT 213. Other PI July 22 GMT 203. No direct O10 video.'
    derived=d.timetuple().tm_yday if d else None
    if gd is None: flags.append('gmt_missing')
    elif derived!=gd and not any(f in flags for f in ['gmt_corrected_high_confidence','gmt_inferred_provisional']): flags.append('gmt_conflict_unresolved')
    if not d: flags.append('date_missing')
    return dict(date_raw=str(raw) if pd.notna(raw) else '',date_excel_raw=str(xraw) if pd.notna(xraw) else '',date_corrected=d.isoformat() if d else '',gmt_day_raw=gd,gmt_day=derived,date_quality_flag=';'.join(flags) or 'consistent',date_basis='Source comparison; GMT calculated from selected date; inferred choices provisional',date_evidence=evidence,date_alternative=alternative,date_excel_time_raw=start if n==26 else '')
