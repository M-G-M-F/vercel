from pathlib import Path
import json, hashlib
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
T=R/'output/analysis/T1'
E=T/'extra'; E.mkdir(exist_ok=True)
def dump(p,obj): p.write_text(json.dumps(obj,indent=2,ensure_ascii=False),encoding='utf-8')
d=pd.read_csv(T/'dashboard_runs.csv'); evidence=[]; checks=[]
def check(name,ok): checks.append((name,bool(ok)))
check('250 unique run IDs',len(d)==250 and d.run_id.is_unique)
check('Source provenance present',d[['source_file','source_row']].notna().all().all())
check('GMT matches selected date',pd.to_datetime(d.date_corrected).dt.dayofyear.eq(d.gmt_day).all())
check('Chronological order within investigation',all(g.date_corrected.is_monotonic_increasing for _,g in d.groupby('investigation_id',sort=False)))
for pid,g in d.groupby('investigation_id'):
 folder=next(p for p in T.glob(pid+'_*') if p.is_dir()); tab=folder/'tables'; chart=folder/'charts'
 for line in (folder/'findings.md').read_text().splitlines():
  parts=line.split(' | ')
  if len(parts)==7:
   i,s,l,f,r,c,n=parts; evidence.append(dict(id=i,snippet=s,record_folder=folder.name,label=l,source_file=f,rows_or_page=r,confidence=c,limitations=n))
 stats=g.groupby('material_or_fuel',dropna=False).oxygen_pct.agg(['size','count','min','median','max']).reset_index(); stats.to_csv(tab/'material_oxygen_coverage.csv',index=False)
 sample=g.groupby('x_sample_id',dropna=True).size(); repeated=sample[sample>1]; ids=g.loc[g.x_sample_id.isin(repeated.index),'run_id'].tolist()
 # Sample labels are not necessarily globally unique; report labels rather than independent specimens.
 i='F-T1-'+pid[-2:]+'05'; claim=f'{len(ids)} of {len(g)} rows share a nonmissing sample label with another row in this investigation.'
 item=dict(id=i,snippet=claim,record_folder=folder.name,label='OBSERVED IN DATA',source_file='dashboard_runs.csv',rows_or_page=ids,confidence='high',limitations='Sample labels can recur across investigators; this does not establish physical specimen identity or independence.')
 evidence.append(item); dump(tab/'derived_coverage.json',{'records':len(g),'oxygen_nonmissing':int(g.oxygen_pct.notna().sum()),'sample_labels_repeated':len(repeated),'rows_with_repeated_labels':len(ids),'date_flags':g.date_quality_flag.value_counts().to_dict()})
 fig,ax=plt.subplots(figsize=(8,4.5)); groups=[(str(k),v.oxygen_pct.dropna()) for k,v in g.groupby('material_or_fuel') if v.oxygen_pct.notna().any()]; ax.boxplot([v for _,v in groups],tick_labels=[f'{k}\n(n={len(v)})' for k,v in groups]); ax.set_ylabel('Recorded oxygen (%)'); ax.set_title(pid+' | oxygen conditions by material'); ax.tick_params(axis='x',labelsize=8); fig.tight_layout(); fig.savefig(chart/'oxygen_by_material.png',dpi=150); plt.close(fig)
 (chart/'oxygen_by_material_caption.txt').write_text('Recorded oxygen conditions, not flammability thresholds. Group sizes are run rows, not independent samples. See tables/material_oxygen_coverage.csv.')
 (folder/'model').mkdir(exist_ok=True); (folder/'model/no_model.md').write_text('No predictive model: no validated common outcome label. Descriptive oxygen baseline only; no causal or safety ranking.')
 card=json.loads((folder/'card.json').read_text()); dump(folder/'card_summary.json',{'id':pid,'title':card['title'],'fuel_type':'solid','hardware_family':'ISS Microgravity Science Glovebox','conditions':{'oxygen_pct_observed':[float(g.oxygen_pct.min()),float(g.oxygen_pct.max())],'gravity':['microgravity']},'tests':{'run_records':len(g)},'data_readiness':'processed-table','limitations':['No validated common outcome','Repeated sample labels','Some dates provisional','Raw videos not analysed']})
check('All evidence entries have provenance',all(x['rows_or_page'] and x['source_file'] for x in evidence))
dump(E/'evidence_snippets.json',evidence)
(E/'limitations.md').write_text('T1 limitations\n\nRecorded oxygen is not a limiting oxygen index. No material hazard ranking or causal comparison. Sample labels may be reused. PSI-26 oxygen unit conversion is inferred; airflow is not standardised across investigations. Date corrections marked provisional require original records; no claim of scientific verification. Raw videos were not analysed.\n')
(E/'test_questions.md').write_text('T1 retrieval questions\n\n1. How many records? PSI-25: 129; PSI-26: 121.\n2. Can oxygen ranges rank hazards? No.\n3. Are all corrected dates confirmed? No, see date_review.csv.\n4. Why no predictive model? No validated common target.\n5. Where are original row references? dashboard_runs.csv and evidence_snippets.json.\n')
(E/'track_paragraph.md').write_text('T1 covers BASS and BASS-II solid-fuel combustion in microgravity. The package provides 250 traceable run records, descriptive oxygen and material analysis, and a date audit. It does not establish fire safety thresholds.\n')
(E/'README.md').write_text('Machine-readable evidence, retrieval questions, scope limitations and a dashboard summary. Generated by enhance.py. Evidence row IDs refer to the dashboard unless a source file is named.\n')
(T/'SELF_CHECK.md').write_text('T1 automated checks\n\n'+'\n'.join(f'- {n}: {"PASS" if v else "FAIL"}' for n,v in checks)+'\n- Scientific date verification, team review and official validator: pending.\n')
with (T/'si_log.md').open('a') as f: f.write('\nV5: AI-assisted package comparison, evidence indexing, coverage charts and automated checks; human review pending.\n')
with (T/'HANDOFF.md').open('a') as f: f.write('\nV5 additions: extra/ evidence and retrieval pack, material oxygen coverage, repeated-label summary, compact cards, two charts and self-check. See extra/limitations.md.\n')
# Add self-contained sections to existing plain-text RAG pack, without hash headings.
rag=T/'Amr_BASS_Deep_Analysis_v4_clean.txt'; out=T/'Amr_BASS_Deep_Analysis_v5_clean.txt'; out.write_text(rag.read_text(encoding='utf-8')+'\n\n'+'\n\n'.join(f'[CHUNK {x["id"]}] Evidence summary\n{x["snippet"]}\nSource: {x["source_file"]}; rows: {x["rows_or_page"]}\nConfidence: {x["confidence"]}. Limit: {x["limitations"]}' for x in evidence),encoding='utf-8')
assert all(v for _,v in checks),checks
print(checks)
