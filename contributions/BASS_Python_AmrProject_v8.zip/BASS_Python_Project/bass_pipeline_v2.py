import argparse, pathlib, re, json, hashlib, inspect
import pandas as pd
from bass_dates import reconcile
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=argparse.ArgumentParser(); P.add_argument('--input',default='/content/drive/MyDrive/NASA'); P.add_argument('--output',default='BASS_package'); a=P.parse_args()
base=pathlib.Path(a.input); root=pathlib.Path(a.output)/'analysis/T1'; root.mkdir(parents=True,exist_ok=True)
files=['PSI-25_BASS-II_raw.csv','PSI-26_BASS_raw.csv','BASS-II%20Test%20Matrix%20by%20PI%20Final.xlsx','BASS%20test%20matrix.xlsx']
paths=[base/f if (base/f).exists() else base/f.replace('%20',' ') for f in files]
hashes=lambda: {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
before=hashes(); required='investigation_id run_id source_file source_row material_or_fuel gravity_level oxygen_pct pressure_kpa flow_speed_value flow_speed_unit outcome_raw outcome_norm notes'.split()
def val(x): return '' if pd.isna(x) else str(x).strip()
def ident(x): return re.sub(r'\.0$','',val(x)).upper()
def num(x):
 try: return float(val(x)) if re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)',val(x)) else np.nan
 except: return np.nan

def material(x):
 s=val(x).lower()
 for pattern,label in [(r'pmma|poly.?methyl','PMMA'),(r'sibal','SIBAL'),(r'nomex','Nomex'),(r'wax|candle','Wax'),(r'cotton','Cotton'),(r'cellulose','Cellulose')]:
  if re.search(pattern,s): return label
 return 'Unclassified' if s else ''

def norm(x): return re.sub(r'\s+',' ',val(x).lower())
def source(path,sheet=None,header=0):
 d=pd.read_csv(path) if sheet is None else pd.read_excel(path,sheet_name=sheet,header=header)
 return [(f'{sheet}!{i+header+2}' if sheet else str(i+2),r.to_dict()) for i,r in d.iterrows()],d

def run(n):
 id=f'PSI-{n}'; slug='bass-ii' if n==25 else 'bass'; out=root/f'{id}_{slug}'; (out/'tables').mkdir(parents=True,exist_ok=True); (out/'charts').mkdir(exist_ok=True); (out/'scripts').mkdir(exist_ok=True)
 csv=paths[0 if n==25 else 1]; xl=paths[2 if n==25 else 3]; logs=[]; rows=[]; profiles=[]; mappings=[]; cross=[]
 def log(file,row,col,old,new,why): logs.append([file,row,col,val(old),val(new),why,f'bass_pipeline_v2.py:{inspect.currentframe().f_back.f_lineno}'])
 def profile(file,sheet,d): profiles.append(f'### {file} / {sheet}\nBytes: {(base/file).stat().st_size if (base/file).exists() else 0}; shape: {d.shape}; exact duplicates: {d.duplicated().sum()}\n\n'+d.isna().sum().to_frame('missing').to_markdown()+'\n')
 cr,cd=source(csv); profile(csv.name,'CSV',cd); sheets=pd.ExcelFile(xl).sheet_names if n==25 else ['as run matrix']; xr=[]
 for sh in sheets:
  rr,dd=source(xl,sh,0 if n==25 else 2); profile(xl.name,sh,dd); xr.extend(rr)
 def key(r,excel):
  if n==25:return ident(r.get('Test no.' if excel else 'Test #'))
  return (ident(r.get('As run test no.' if excel else 'As Run Test #')),ident(r.get('Test no.' if excel else 'Test #')),ident(r.get('Sample no.' if excel else 'Sample #')))
 primary=cr if n==25 else xr; secondary=xr if n==25 else cr; pf=csv if n==25 else xl; sf=xl if n==25 else csv
 for row,r in primary:
  k=key(r,n==26)
  if (n==25 and not k) or (n==26 and (not re.fullmatch(r'\d+',k[0]) or not k[1])):
   log(pf.name,row,'record',str(r),'','Excluded from run table: no valid run identifier; original retained'); continue
  matches=[(sr,s) for sr,s in secondary if key(s,n==25)==k]; sr,s=matches[0] if len(matches)==1 else ('',{})
  cross.append({'source_row':row,'key':str(k),'match_count':len(matches),'secondary_row':sr,'secondary_file':sf.name})
  if len(matches)!=1: log(pf.name,row,'crosswalk',str(k),len(matches),'No enrichment from ambiguous/unmatched record')
  rawmat=r.get('Fuel Sample Material' if n==25 else 'material'); mat=material(rawmat); mappings.append((val(rawmat),mat)); log(pf.name,row,'material',rawmat,mat,'Explicit keyword family; no inferred composition')
  notes=[]; record=dict.fromkeys(required,''); record.update(investigation_id=id,run_id=f'{id}:'+ (k if n==25 else ':'.join(k))+':'+row,source_file=pf.name,source_row=row.split('!')[-1],x_source_sheet=row.split('!')[0] if '!' in row else '',material_or_fuel=mat,gravity_level='microgravity_ISS',x_material_raw=val(rawmat),x_sample_id=ident(r.get('Sample #' if n==25 else 'Sample no.')),x_test_id=k if n==25 else k[1],x_secondary_file=sf.name if sr else '',x_secondary_row=sr)
  for col,v in r.items(): record['raw_'+re.sub(r'\W+','_',col.lower()).strip('_')]=val(v)
  def numeric(col,target,scale=1,limits=None):
   z=r.get(col); x=num(z); y=x*scale
   if limits and pd.notna(y) and not limits[0]<=y<=limits[1]: y=np.nan
   if pd.notna(z): log(pf.name,row,col,z,y,'Strict scalar conversion; factor '+str(scale)+'; nonnumeric/invalid stays blank')
   record[target]=y; return y
  if n==25:
   ini=numeric('Calibrated  initial O2 % by vol ','x_oxygen_pct_initial',limits=(0,100)); fin=numeric('Calibrated final O2 % by vol','x_oxygen_pct_final',limits=(0,100));record['oxygen_pct']=ini;notes.append('oxygen_pct is initial calibrated O2')
   if k in ['B2','T28A','T28B'] or (pd.notna(ini) and pd.notna(fin) and abs(ini-fin)>10): notes.append('Suspicious O2 change; exclude from paired summary pending review');record['x_oxygen_review']=True
   else: record['x_oxygen_review']=False
   for gas,col in [('co2_initial_pct','Initial CO2 % by vol'),('co2_final_pct','Final CO2 % by vol'),('co_initial_ppm','Initial CO (ppm)'),('co_final_ppm','Final CO (ppm)')]: numeric(col,'x_'+gas)
   record['x_pi']=val(r.get('PI')); record['flow_speed_value']=numeric('Air display','x_air_scalar',limits=(0,100));record['flow_speed_unit']='cm/s' if pd.notna(record['flow_speed_value']) else '';notes.append('Air display unit from BASS-II FAQ; multi-setting values kept raw')
  else:
   numeric('O2 % by volume','oxygen_pct',100,(0,100)); numeric('pressure, atm','pressure_kpa',101.325,(0,200));notes.append('O2 stored as fraction, converted ×100; pressure atm ×101.325');record['outcome_raw']=val(r.get(next(c for c in r if c.startswith('Test Observations'))));notes.append('Outcome narrative not automatically labelled; PSI-26 airflow unit not independently verified')
  dates=reconcile(n,r,s); record.update(dates); log(pf.name,row,'date',dates['date_raw'],dates['date_corrected'],dates['date_quality_flag']);
  record['notes']='; '.join(notes); log(pf.name,row,'source_row',row,record['source_row'],'Numeric source row for team validator; sheet retained in x_source_sheet'); rows.append(record)
 d=pd.DataFrame(rows); d=d.sort_values('date_corrected',key=lambda x:x.replace('', '9999-99-99'),kind='stable').reset_index(drop=True); d=d[required+[c for c in d if c not in required]]; assert d.run_id.is_unique and d.source_row.ne('').all(); d.to_csv(out/'tables'/f'{id}_{slug}_runs_clean.csv',index=False)
 pd.DataFrame(cross).to_csv(out/'tables/crosswalk.csv',index=False);pd.DataFrame(sorted(set(mappings)),columns=['raw_material','family']).to_csv(out/'tables/material_mapping.csv',index=False)
 pd.DataFrame(logs,columns=['file','row','column','before','after','reason','script and line']).to_csv(out/'tables/change_log.csv',index=False)
 (out/'data_log.md').write_text('file | row | column | before | after | reason | script and line\n\nFull row-level log: tables/change_log.csv. Raw source columns retained. No imputation. CSV row numbers count header as 1; Excel row references include sheet. Non-run rows excluded only from derived table.\n')
 (out/'profile.md').write_text('\n'.join(profiles)+f'\nClean runs: {len(d)}. Distinct raw material descriptions: {d.x_material_raw.nunique()}.\n')
 counts=d.material_or_fuel.value_counts();counts.to_csv(out/'tables/material_counts.csv'); d[required].replace('',np.nan).isna().sum().to_csv(out/'tables/missing_counts.csv');
 o=pd.to_numeric(d.oxygen_pct,errors='coerce'); o.describe().to_csv(out/'tables/oxygen_summary.csv')
 for series,title,name in [(counts,'Recorded runs by material family','material_counts'),(o.dropna(),'Reported oxygen concentration (%)','oxygen_distribution')]:
  fig,ax=plt.subplots(figsize=(8,4)); series.plot.bar(ax=ax) if name=='material_counts' else ax.hist(series,bins=12);ax.set_title(title);ax.set_ylabel('Run count');fig.tight_layout();fig.savefig(out/'charts'/f'{name}.png',dpi=150);plt.close(fig)
 (out/'charts/captions.md').write_text(f'Both charts: {pf.name}, run rows identified in cleaned CSV. Counts are not flammability rankings.\n')
 findings=[f'{len(d)} run records retained.',f'{d.x_material_raw.nunique()} distinct raw material descriptions recorded.',f'{o.notna().sum()} runs have numeric oxygen; observed range {o.min():.2f}–{o.max():.2f}%.']
 if n==25:
  pair=d.loc[~d.x_oxygen_review].dropna(subset=['x_oxygen_pct_initial','x_oxygen_pct_final']); diff=pair.x_oxygen_pct_final-pair.x_oxygen_pct_initial; diff.describe().to_csv(out/'tables/paired_oxygen_summary.csv');findings.append(f'{len(pair)} unflagged complete oxygen pairs; median final minus initial {diff.median():.3f} percentage points.'); caveat='Descriptive only; repeated samples and variable settings; no causal or safety threshold claim.'
 else: caveat='Narrative outcomes not coded; repeated samples; oxygen conversion assumes fraction representation.'
 (out/'findings.md').write_text('\n'.join(f'F-T1-{n}{i:02d} | {f} | OBSERVED IN DATA | {pf.name} | '+', '.join((d.x_source_sheet.where(d.x_source_sheet.eq(''),d.x_source_sheet+'!')+d.source_row.astype(str)))+' | medium | '+caveat for i,f in enumerate(findings,1)))
 (out/'no_model.md').write_text('Model gate not passed: no validated consistent outcome labels; PSI-25 lacks explicit outcome and PSI-26 narratives require review. No baseline predictive evaluation or grouped holdout performed.\n')
 (out/'scripts/README.md').write_text('Run shared T1/scripts/bass_pipeline.py with --input RAW_FOLDER --output OUTPUT_FOLDER.\n')
 card=dict(investigation_id=id,title='Burning and Suppression of Solids'+(' - II' if n==25 else ''),acronym=slug.upper(),doi='10.60555/4qc4-de67' if n==25 else '10.60555/58h4-dy80',license='CC0-1.0',version=4,sub_research_area='Spacecraft Fire Safety',related_investigations=['PSI-26'] if n==25 else ['PSI-107','PSI-25'],size_on_page='255.77 GB' if n==25 else '152.32 GB',file_types_and_counts='unconfirmed',has_experiment_table='yes',objectives='unconfirmed',approach='ISS microgravity investigation; detailed method pending review',publications='unconfirmed',verified_on='2026-11-15 (user screenshots; exact verification time unconfirmed)',verified_by='User screenshots; reviewer confirmation pending')
 (out/'card.json').write_text(json.dumps(card,indent=2));print(id,len(d),len(findings),o.notna().sum(),o.min(),o.max());return d
D=[run(25),run(26)]; assert before==hashes(); (root/'raw_hashes.json').write_text(json.dumps(before,indent=2));pd.concat(D,ignore_index=True).sort_values('date_corrected',key=lambda x:x.replace('', '9999-99-99'),kind='stable').to_csv(root/'dashboard_runs.csv',index=False)
(root/'references.md').write_text('NASA PSI-25 https://doi.org/10.60555/4qc4-de67\n\nNASA PSI-26 https://doi.org/10.60555/58h4-dy80\n\nBASS-II data FAQ.docx (air display units and instrument limitations).\n\nTools: Python, pandas, NumPy, matplotlib, openpyxl, ChatGPT.\n')
(root/'si_log.md').write_text('2026-11-15 | ChatGPT | requested full preprocessing and packaging | AI-generated Python, documentation and descriptive charts | T1 package | executed on supplied files; human review pending.\n2026-11-15 | ChatGPT | validation and baseline | reproducible audit and descriptive statistics | v2 scripts and tables | automated checks; human review pending.\n')
(root/'HANDOFF.md').write_text('T1 – Amr Morgan | draft package v1 | 2026-11-15\n\nRecords PSI-25 and PSI-26 identified in user screenshots. Two run tables, combined dashboard CSV, charts, source crosswalks, logs and descriptive findings. No model.\n\nSelf-check: required columns and provenance asserted; raw SHA-256 unchanged; no raw video included. Units: PSI-26 oxygen fraction conversion needs reviewer confirmation; PSI-26 airflow not populated. Findings and citations present; independent human spot-check, formal team validator and official citation metadata pending. Baseline causal relation and outcome coding pending user method selection/approval. Notes/concepts require user authorship. File census unconfirmed.\n')
