"""Add traceable T1-only features, sensitivity checks and dataset-specific RAG exports."""
from pathlib import Path
import re,json,hashlib,shutil,tempfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent; T=R/'output/analysis/T1'; E=T/'extra'
D=pd.read_csv(T/'dashboard_runs.csv',dtype=str,keep_default_na=False)
P=['investigation_id','run_id','source_file','source_row','x_source_sheet','x_test_id','x_secondary_file','x_secondary_row']
NUM=r'(?:\d+(?:\.\d*)?|\.\d+)'

def airflow(s):
    s=s.strip()
    if not s: return 'missing',[]
    if re.fullmatch(NUM,s): return 'scalar', [float(s)]
    if re.fullmatch(NUM+r'(?:(?:\s*,\s*|\s+)'+NUM+r')+',s): return 'numeric_sequence', [float(x) for x in re.findall(NUM,s)]
    return 'qualified_or_mixed',[]

def gas(s, is_co=False):
    s=s.strip(); low=s.lower()
    if low in ('','none','nan'): return 'missing',None,None
    if is_co and low=='or': return 'right_censored',None,1000.0 # FAQ: OR >1000 ppm
    if is_co and low=='over': return 'overrange_unspecified',None,None
    if is_co and re.fullmatch(r'>\s*'+NUM,s): return 'right_censored',None,float(re.findall(NUM,s)[0])
    if re.fullmatch(r'[+-]?'+NUM,s):
        v=float(s)
        if v<0 or (not is_co and v>100): return 'out_of_physical_range',None,None
        return 'numeric',v,None
    return 'unparsed',None,None

def material(row):
    raw=row.x_material_raw.lower(); pi=row.x_pi
    if row.material_or_fuel!='Unclassified': return row.material_or_fuel,'explicit_keyword'
    if row.investigation_id=='PSI-25':
        if (pi in ['Olson','Fernandez-Pello'] and 'rod' in raw) or (pi=='Bhattacharjee' and ('film' in raw or 'micron' in raw)) or (pi=="T'ien" and 'spherical section' in raw):
            return 'PMMA','inferred_PI_and_description_FAQ'
    return 'Unclassified','unresolved'

def ncol(g,c): return pd.to_numeric(g[c],errors='coerce')
def dump(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
F=D[P].copy(); F['x_as_run_id']=D.raw_as_run_test_no.where(D.investigation_id.eq('PSI-26'),''); F['x_date_selected']=D.date_corrected;F['x_date_quality_flag']=D.date_quality_flag
F['x_material_family_keyword']=D.material_or_fuel
mf=[material(r) for r in D.itertuples()]; F['x_material_family_context']=[x[0] for x in mf]; F['x_material_basis']=[x[1] for x in mf]
a=[airflow(s) for s in D.raw_air_display]; F['x_air_display_raw']=D.raw_air_display;F['x_air_parse_status']=[x[0] for x in a]; F['x_air_listed_values_json']=[json.dumps(x[1]) if x[1] else '' for x in a]; F['x_air_listed_count']=[len(x[1]) for x in a]; F['x_air_listed_min']=[min(x[1]) if x[1] else np.nan for x in a];F['x_air_listed_max']=[max(x[1]) if x[1] else np.nan for x in a];F['x_air_listed_unit_basis']=np.where(D.investigation_id.eq('PSI-25'),'cm/s reported display (FAQ; ~1 min response)','unit unconfirmed; raw display only')
F['x_fan_display_raw']=D.raw_fan_display;F['x_flow_restrictor_raw']=D.raw_flow_restrictor
for phase in ['initial','final']:
 for name,unit in [('co','ppm'),('co2','by_vol')]:
    col=f'raw_{phase}_{name}_{unit}'; key=f'x_{name}_{phase}'; vals=[gas(s,name=='co') if pid=='PSI-25' else ('not_available',None,None) for s,pid in zip(D[col],D.investigation_id)]
    F[key+'_status']=[x[0] for x in vals]; F[key+'_valid_value']=[x[1] for x in vals];F[key+'_lower_bound']=[x[2] for x in vals]; F[key+'_raw']=D[col]
G=D[D.investigation_id.eq('PSI-25')].copy(); delta=ncol(G,'x_oxygen_pct_final')-ncol(G,'x_oxygen_pct_initial');flag=G.x_oxygen_review.str.lower().eq('true');
F['x_o2_change_pp']=delta.reindex(D.index); F['x_o2_pair_review']=np.where(D.investigation_id.eq('PSI-25'),np.where(D.x_oxygen_review.str.lower().eq('true'),'review',np.where(F.x_o2_change_pp.notna(),'complete','missing')),'not_available')
# Sensitivity is not a scientific threshold. Retain manually flagged IDs in all screened scenarios.
manual=G.x_test_id.isin(['B2','T28A','T28B']); sens=[]
for name,mask in [('all_numeric_pairs',delta.notna()),('v5_review_exclusion',delta.notna()&~flag)]+[(f'abs_change_le_{cut}_pp_and_manual_exclusions',delta.notna()&~manual&delta.abs().le(cut)) for cut in [5,10,15,20]]:
    x=delta[mask];sens.append({'scenario':name,'included_pairs':len(x),'excluded_complete_pairs':int(delta.notna().sum()-len(x)),'mean_change_pp':float(x.mean()),'median_change_pp':float(x.median()),'min_change_pp':float(x.min()),'max_change_pp':float(x.max()),'excluded_run_ids':';'.join(G.loc[delta.notna()&~mask,'run_id'])})
S=pd.DataFrame(sens); S.to_csv(E/'oxygen_sensitivity.csv',index=False)
# Stable reference links and self-contained per-run features.
F.to_csv(E/'run_features.csv',index=False); merged=D.merge(F.drop(columns=[c for c in P if c!='run_id']),on='run_id',validate='one_to_one');merged.to_csv(T/'dashboard_runs_enriched.csv',index=False)
evidence=json.loads((E/'evidence_snippets.json').read_text()); findings=[]; checks=[]
def check(name,ok): checks.append((name,bool(ok))); assert ok,name

def add(pid,num,claim,rows,caveat,confidence='high',label='OBSERVED IN DATA',file=None):
    folder=next(p for p in T.glob(pid+'_*') if p.is_dir());rows=list(rows);fid=f'F-T1-{num}'; source=file or ('PSI-25_BASS-II_raw.csv' if pid=='PSI-25' else 'BASS%20test%20matrix.xlsx'); rowrefs=', '.join(('as run matrix!' if pid=='PSI-26' else '')+str(r) for r in rows)
    findings.append(dict(id=fid,snippet=claim,record_folder=folder.name,label=label,source_file=source,rows_or_page=rowrefs,confidence=confidence,limitations=caveat));
    with (folder/'findings.md').open('a',encoding='utf-8') as f:f.write('\n'+' | '.join([fid,claim,label,source,rowrefs,confidence,caveat]))
    return fid

for pid,g in F.groupby('investigation_id',sort=True):
    folder=next(p for p in T.glob(pid+'_*') if p.is_dir()); tab=folder/'tables'; ch=folder/'charts';orig=D.loc[g.index]; g.to_csv(tab/'run_features.csv',index=False)
    counts=g.x_air_parse_status.value_counts(); counts.rename_axis('status').reset_index(name='records').to_csv(tab/'air_display_coverage.csv',index=False)
    fig,ax=plt.subplots(figsize=(7,3.6));counts.reindex(['scalar','numeric_sequence','qualified_or_mixed','missing'],fill_value=0).plot.bar(ax=ax,rot=15);ax.set_ylabel('Run rows');ax.set_title(pid+' | air display parsing coverage');fig.tight_layout();fig.savefig(ch/'air_display_coverage.png',dpi=150);plt.close(fig)
    text=f'{len(g)} records: '+', '.join(f'{k}={v}' for k,v in counts.items())+'. Numeric sequences are literal listed display values, not a burn-phase measurement.'
    add(pid,int(pid[-2:])*100+10,text,g.source_row,'For PSI-25, FAQ identifies duct display in cm/s with about 1 min lag; for PSI-26 the unit is unconfirmed. No nominal-to-local velocity assumption.')
    cov=pd.crosstab(g.x_material_family_keyword,g.x_material_family_context);cov.to_csv(tab/'material_context_crosswalk.csv')
    card=json.loads((folder/'card.json').read_text());meta=json.loads((R/'metadata'/f'{pid}.json').read_text());card.update(objectives=meta['objective'],approach=meta['approach'],metadata_basis='Supplied PSI JSON snapshot; live catalog not verified.');dump(folder/'card.json',card)
    with (folder/'scripts/README.md').open('w') as f:f.write('From BASS_Python_Project: python main.py. This regenerates preprocessing, audits, charts, RAG corpora and team schema outputs.\n')
    with (ch/'captions.md').open('a') as f:f.write('\nAir display coverage: literal parse categories; no flame-front or steady velocity inference.\n')
    with (folder/'data_log.md').open('a') as f:f.write('\nV6 additive transformations: tables/run_features.csv keeps raw display/gas fields, screened numeric values, censoring, contextual material inference, and provenance per run; original fields unchanged. See extra/FEATURE_DICTIONARY.md and improve_v6.py.\n')
    if pid=='PSI-25':
        inf=g.x_material_basis.eq('inferred_PI_and_description_FAQ');add(pid,2511,f'{inf.sum()} previously Unclassified rows have PMMA as an additional context-inferred family using the material wording and PI descriptions in the BASS-II FAQ.',g.loc[inf,'source_row'],'Inferred, not explicit row-level composition; original family retained.',confidence='medium',label='OUR INFERENCE')
        gas_status=pd.DataFrame([{'field':c,'status':s,'records':int(v)} for c in g if re.fullmatch(r'x_(co|co2)_(initial|final)_status',c) for s,v in g[c].value_counts().items()]);gas_status.to_csv(tab/'gas_quality_summary.csv',index=False)
        neg=g.x_co_initial_status.eq('out_of_physical_range');cens=g.x_co_final_status.isin(['right_censored','overrange_unspecified']);add(pid,2512,f'{neg.sum()} initial CO readings are negative; {cens.sum()} final CO readings are censored or overrange, not exact concentrations.',g.loc[neg|cens,'source_row'],'Screened exact values blank for these rows; raw retained. FAQ defines OR >1000 ppm; explicit >500 remains lower bound; unspecified over not quantified.')
        add(pid,2513,f'Among {int(delta.notna().sum())} complete oxygen pairs, {int(flag.sum())} are flagged. V5 exclusion leaves {len(delta[~flag].dropna())} pairs (median final minus initial {delta[~flag].median():.2f} percentage points); all complete pairs give {delta.median():.2f}.',g.source_row,'Descriptive sensitivity only; sensor offsets, settings and repeated specimens limit interpretation. Cutoffs are review rules, not extinction thresholds.')
        fig,ax=plt.subplots(figsize=(8,4));ax.bar(range(len(S)),S.mean_change_pp,label='Mean');ax.scatter(range(len(S)),S.median_change_pp,label='Median',color='black');ax.set_xticks(range(len(S)),['All','V5','5 pp','10 pp','15 pp','20 pp']);ax.set_ylabel('Final − initial oxygen (percentage points)');ax.set_title('PSI-25 | paired oxygen screening sensitivity');ax.legend();fig.tight_layout();fig.savefig(ch/'oxygen_sensitivity.png',dpi=150);plt.close(fig)
        with (ch/'captions.md').open('a') as f:f.write('Oxygen screening sensitivity: V5 flag rule vs all pairs and 5/10/15/20 pp rules with manual exclusions. Not a physical threshold.\n')

# Validation of original links and raw hashes, plus strict export checks.
check('250 unique feature rows and unchanged original dashboard columns',len(F)==250 and F.run_id.is_unique and merged[D.columns].equals(D))
check('121 PSI-26 and 129 PSI-25 records',D.investigation_id.value_counts().to_dict()=={'PSI-25':129,'PSI-26':121})
check('4 original source SHA-256 hashes unchanged',all(hashlib.sha256((R/'data'/n).read_bytes()).hexdigest()==h for n,h in json.loads((T/'raw_hashes.json').read_text()).items()))
check('250 chronological selected dates agree arithmetically with GMT',D.date_corrected.is_monotonic_increasing and pd.to_datetime(D.date_corrected).dt.dayofyear.eq(ncol(D,'gmt_day')).all())
check('250 unique source crosswalk matches',all(len(pd.read_csv(p))==len(D[D.investigation_id.eq(p.parent.parent.name.split('_')[0])]) and pd.read_csv(p).match_count.eq(1).all() for p in T.glob('PSI-*/tables/crosswalk.csv')))
check('No censored or negative CO used as exact value',F.loc[F.x_co_initial_status.ne('numeric'),'x_co_initial_valid_value'].isna().all() and F.loc[F.x_co_final_status.ne('numeric'),'x_co_final_valid_value'].isna().all())
check('All numeric airflow sequences preserve literal token count',all(len(json.loads(s))==n for s,n in zip(F.x_air_listed_values_json,F.x_air_listed_count) if s))
check('All original material groups retained; contextual-only inference scoped to PSI-25',F.x_material_family_keyword.equals(D.material_or_fuel) and F.loc[D.investigation_id.eq('PSI-26'),'x_material_family_context'].equals(D.loc[D.investigation_id.eq('PSI-26'),'material_or_fuel']))
check('Oxygen sensitivity reproduces existing paired count and median',len(delta[~flag].dropna())==122 and np.isclose(delta[~flag].median(),-.3))
# Team kit requires x_ or raw_ prefix on non-standard run-table columns. Preserve dashboard API; export compatible per-PSI tables.
for p in T.glob('PSI-*/tables/*_runs_clean.csv'):
    d=pd.read_csv(p,dtype=str,keep_default_na=False); extra=[c for c in d.columns[13:] if not c.startswith(('x_','raw_'))];d.rename(columns={c:'x_'+c for c in extra}).to_csv(p,index=False)
# Reconcile evidence provenance: repeated-label V5 entries referenced dashboard run IDs, not raw-file rows.
for item in evidence:
    if isinstance(item['rows_or_page'],list):
        subset=D[D.run_id.isin(item['rows_or_page'])];item['source_file']=subset.source_file.iloc[0];item['rows_or_page']=', '.join((r.x_source_sheet+'!' if r.x_source_sheet else '')+r.source_row for r in subset.itertuples());item['run_ids']=subset.run_id.tolist()
evidence+=findings;dump(E/'evidence_snippets.json',evidence)
check('Every evidence item has a unique ID and source reference',len({x['id'] for x in evidence})==len(evidence) and all(x['source_file'] and x['rows_or_page'] for x in evidence))
(E/'FEATURE_DICTIONARY.md').write_text('''V6 additive data dictionary\n\n- dashboard_runs.csv: preserved V5 interface. dashboard_runs_enriched.csv: same rows plus traceable x_ features. Per-PSI clean tables use x_ prefix for date columns to comply with the team schema.\n- x_as_run_id is the execution sequence in BASS; x_test_id is the planned test identifier. They are not interchangeable or unique on their own. Use run_id.\n- x_material_family_context is an optional PI/FAQ-based family hypothesis; x_material_family_keyword is the original conservative label. Never report the inferred label as observed composition.\n- x_air_listed_values_json retains order of literal numbers only for complete numeric lists. Qualified strings, ranges, pot values and text are excluded rather than stripped; raw retained. No timing, steady state, extinction or local airflow asserted. PSI-25 FAQ states cm/s and ~1 min instrument response; PSI-26 unit unconfirmed. Fan display and flow restriction are separate.\n- x_co/ co2 phase status, valid_value, lower_bound: exact physically nonnegative numerics only; CO OR is >1000 ppm per FAQ, >500 is explicit lower bound. Over unspecified remains unknown; negatives kept raw. No imputation. CO2 units as source (% by volume).\n- x_o2_change_pp: final minus initial calibrated oxygen, percentage points, not a combustion rate. Review flag unchanged.\n''',encoding='utf-8')
# Correct stale statements and enrich per-run RAG records; no synthetic outcomes.
rag=(T/'Amr_BASS_Deep_Analysis_v5_clean.txt').read_text(encoding='utf-8').replace('Team-wide validator not executed; human review', 'Team-kit structural validator is included; human review').replace('FAQ itself not bundled','FAQ bundled in metadata/BASS-II data FAQ.docx').replace('25 scalar BASS-II readings under an unconfirmed unit interpretation','25 scalar BASS-II display readings in cm/s according to supplied FAQ; steady state not confirmed').replace('Test 93: Apr','As-run sequence 93: Apr').replace('Test 111: May','As-run sequence 111: May').replace('tests 112-116:','as-run sequences 112-116:')
parts=re.split(r'(?=^\[CHUNK )',rag,flags=re.M); idx=F.set_index('run_id');seen=[]; new=[]
for chunk in parts:
    m=re.search(r'^\[CHUNK T1-(25|26)-RUN-[^\]]+\].*?\| run (.+)$',chunk,re.M)
    if m:
        rid=m.group(2).strip();r=idx.loc[rid];seen.append(rid); extras=[f'planned_test_id: {r.x_test_id}',f'as_run_sequence: {r.x_as_run_id or "not applicable"}',f'material_family_context: {r.x_material_family_context}; basis: {r.x_material_basis}',f'air_display_raw: {r.x_air_display_raw or "missing"}; parse: {r.x_air_parse_status}; listed values: {r.x_air_listed_values_json or "not extracted"}; {r.x_air_listed_unit_basis}',f'fan_display_raw: {r.x_fan_display_raw or "missing"}; flow_restrictor_raw: {r.x_flow_restrictor_raw or "missing"}']
        if m.group(1)=='25':
            extras += [f'{k}: {r[k+"_raw"] or "missing"}; status={r[k+"_status"]}; exact={r[k+"_valid_value"] if pd.notna(r[k+"_valid_value"]) else "missing"}; lower_bound={r[k+"_lower_bound"] if pd.notna(r[k+"_lower_bound"]) else "not applicable"}' for k in ['x_co_initial','x_co_final','x_co2_initial','x_co2_final']];extras += [f'oxygen_change_pp: {r.x_o2_change_pp if pd.notna(r.x_o2_change_pp) else "missing"}; pair status: {r.x_o2_pair_review}']
        chunk=chunk.rstrip()+'\n[V6 derived fields; original row provenance above; BASS-II FAQ for unit and PI context]\n'+'\n'.join(extras)+'\n\n'
    # Rebuild legacy evidence chunks from the corrected provenance index.
    em=re.match(r'^\[CHUNK (F-T1-\d+)\]',chunk)
    if em:
        item=next(x for x in evidence if x['id']==em.group(1));chunk=f'[CHUNK {item["id"]}] {item["record_folder"]} evidence\n[{item["label"]}] {item["snippet"]}\nSource: {item["source_file"]}; rows: {item["rows_or_page"]}\nConfidence: {item["confidence"]}. Limit: {item["limitations"]}\n\n'
    new.append(chunk)
check('All 250 RAG run chunks match unique run IDs',len(seen)==250 and set(seen)==set(D.run_id))
more=[]
for x in findings:
    more.append(f'[CHUNK {x["id"]}] {x["record_folder"]} evidence\n[{x["label"]}] {x["snippet"]}\nSource: {x["source_file"]}; rows: {x["rows_or_page"]}\nConfidence: {x["confidence"]}. Limit: {x["limitations"]}\n\n')
more.append('[CHUNK T1-25-SENSITIVITY] Oxygen review sensitivity\n'+S.drop(columns='excluded_run_ids').to_string(index=False)+'\nSource: PSI-25_BASS-II_raw.csv; exact included/excluded IDs in extra/oxygen_sensitivity.csv. Review-rule sensitivity, not a fire boundary.\n\n')
more.append('[CHUNK T1-V6-METHOD] V6 enrichment\n'+(E/'FEATURE_DICTIONARY.md').read_text().replace('#','')+'\n\n')
combined=''.join(new+more);combined=re.sub(r'^#+[ \t]*','',combined,flags=re.M);out=T/'Amr_BASS_Deep_Analysis_v6_clean.txt';out.write_text(combined,encoding='utf-8')
chunks=re.split(r'(?=^\[CHUNK )',combined,flags=re.M); ids=re.findall(r'^\[CHUNK ([^\]]+)\]',combined,re.M);check('Unique RAG chunk identifiers',len(ids)==len(set(ids)))
# Shared overview is included in both corpora; dataset-specific chunks never enter the other corpus.
for pid in ['25','26']:
    scope=[c for c in chunks[1:] if re.match(r'\[CHUNK (?:T1-'+pid+r'-|F-T1-'+pid+r'\d+\])',c) or re.match(r'\[CHUNK T1-(?:00|01|DATE-AUDIT|90|91|92|93|V6-METHOD)\]',c)]
    title='BASS-II' if pid=='25' else 'BASS'; f=next(p for p in T.glob('PSI-'+pid+'_*') if p.is_dir())/'rag_corpus.txt';f.write_text(f'{title} (PSI-{pid}) - RAG corpus\nSource IDs: S1 PSI-26 metadata; S2 PSI-25 metadata; S3 PSI-26 CSV; S4 BASS workbook; S5 PSI-25 CSV; S6 BASS-II workbook; S7 preprocessing and audit; BASS-II data FAQ.docx. Shared T1 context is labelled; use only matching investigation for run evidence.\n\n'+''.join(scope),encoding='utf-8')
    s=f.read_text();check(f'PSI-{pid} corpus has correct run count and no foreign run chunk',len(re.findall(r'^\[CHUNK T1-'+pid+r'-RUN-',s,re.M))==({'25':129,'26':121}[pid]) and not re.search(r'^\[CHUNK T1-'+('26' if pid=='25' else '25')+r'-RUN-',s,re.M))
(E/'test_questions.md').write_text('''T1 RAG acceptance questions (expected answers and evidence)\n\nAnswerable\n1. How many runs? 129 BASS-II, 121 BASS (T1-01).\n2. How much oxygen coverage? 129/129 PSI-25; 121/121 PSI-26 (T1-25-03, T1-26-03).\n3. Why are some PSI-25 PMMA labels contextual? PI-specific fuel descriptions in FAQ; original label unchanged (F-T1-2511).\n4. How should CO OR or >500 be used? Censored, not exact; OR >1000 ppm per FAQ (F-T1-2512).\n5. How sensitive is the paired oxygen result to exclusions? Use T1-25-SENSITIVITY; V5 median -0.30 pp with 122 pairs.\n6. What do airflow sequences represent? Literal display entries, not a timed or steady flame velocity (F-T1-2510, F-T1-2610).\n7. Are all dates independently confirmed? No; nine provisional year/date/GMT choices including T9/T18 (T1-DATE-AUDIT).\n\nNot answerable\n8. What oxygen percentage is safe on the ISS? No validated safety threshold (T1-91).\n9. Which material is safest? No controlled hazard ranking (T1-90).\n10. What is exact flame extinction velocity? No synchronized validated outcome or steady-flow series (T1-V6-METHOD).\n11. Can we predict burn duration? No validated common target (T1-91).\n\nThese are expected-answer fixtures, not a measured chatbot benchmark.\n''',encoding='utf-8')
(E/'V6_CHANGES.md').write_text('''V6 improvements after review of the supplied team packages\n\nShreif T2 v6: adopted sensitivity analysis, normalization/coverage and explicit distinction between nominal and measured airflow; no SAFFIRE measurements transferred.\nNadeem T3: adopted answerable/unanswerable retrieval fixtures and evidence-linked responses; no smoke detector model transferred.\nGamal: adopted claim/evidence/why-it-matters/caveat approach and local airflow caution; no SLICE or SPICE results transferred.\nT1-specific additions: contextual PMMA inference based on supplied FAQ, censored gas semantics, dataset-level corpora and unique run IDs, team-compatible date-column prefixes. Existing derived numbers preserved; enriched files are additive.\n''',encoding='utf-8')
with (E/'limitations.md').open('a') as f:f.write('\nV6: contextual material labels are hypotheses; numeric airflow sequences are display entries, not timing or extinction data. CO negatives and censoring are not exact concentrations; oxygen screening sensitivity is not a physical threshold. RAG retrieval fixtures have not been evaluated against a deployed retriever.\n')
with (T/'HANDOFF.md').open('a') as f:f.write('\nV6: additive enriched dashboard, run features, gas audit, oxygen screening sensitivity, separate RAG corpora and explicit retrieval fixtures. See extra/V6_CHANGES.md and extra/FEATURE_DICTIONARY.md.\n')
with (T/'si_log.md').open('a') as f:f.write('\n2026-11-15 | ChatGPT | review supplied peer packages | T1-specific additive features, RAG validation and schema export | improve_v6.py | automated checks; human scientific review pending.\n')
# Run exact team-kit self-check against temporary staged source copies when available.
try:
    from tools import self_check as team
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);shutil.copytree(T,root/'analysis/T1');(root/'data/raw').mkdir(parents=True)
        for n in json.loads((T/'raw_hashes.json').read_text()):shutil.copy2(R/'data'/n,root/'data/raw'/n)
        pd.DataFrame([{'path':'data/raw/'+n,'sha256':h} for n,h in json.loads((T/'raw_hashes.json').read_text()).items()]).to_csv(root/'data/CHECKSUMS.csv',index=False)
        res=team.check('T1',root=root);(T/'TEAM_SELF_CHECK.md').write_text(team.render('T1',res)+'\nLive NASA metadata and human sign-off are not authenticated by the automated validator.\n',encoding='utf-8');check('Team kit validator has no FAIL status',not any(x[2]=='FAIL' for x in res))
except ImportError:
    (T/'TEAM_SELF_CHECK.md').write_text('Optional team checker not bundled or importable; not run.\n')
(T/'SELF_CHECK.md').write_text('T1 V6 checks\n\n'+'\n'.join(f'- {name}: {"PASS" if ok else "FAIL"}' for name,ok in checks)+'\n\nLive metadata, original video/log confirmation and human review remain pending.\n',encoding='utf-8')
# Intermediate corpus versions are regenerated by earlier steps but excluded from final RAG delivery.
for p in T.glob('Amr_BASS_Deep_Analysis_v[45]*.txt'): p.unlink()
if (T/'COMPARISON.md').exists(): (T/'COMPARISON.md').unlink()
print('V6',len(checks),'checks passed');print(F.groupby(['investigation_id','x_air_parse_status']).size());print(F.x_material_basis.value_counts());print(S[['scenario','included_pairs','mean_change_pp','median_change_pp']].to_string(index=False))
