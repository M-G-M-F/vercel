"""Publish one screened analytical layer and update all RAG exports from it.
Raw sources and the audit values are preserved; no invented measurements.
"""
from pathlib import Path
import json,re,hashlib
import pandas as pd
R=Path(__file__).resolve().parent; T=R/'output/analysis/T1'; E=T/'extra'
def read(p): return pd.read_csv(p,dtype=str,keep_default_na=False)
def write(d,p): d.to_csv(p,index=False)
D=read(T/'dashboard_runs_enriched.csv'); assert len(D)==250 and D.run_id.is_unique
links={
 'may17':'https://www.nasa.gov/blogs/stationreport/2013/05/17/iss-daily-summary-report-05-17-13/',
 'may30':'https://www.nasa.gov/blogs/stationreport/2013/05/',
 'june24':'https://www.nasa.gov/blogs/stationreport/2014/06/24/iss-daily-summary-report-06-24-14/',
 'july22':'https://www.nasa.gov/blogs/stationreport/2014/07/22/iss-daily-summary-report-07-22-14/',
 'aug1':'https://www.nasa.gov/blogs/stationreport/2014/08/01/iss-daily-summary-report-08-01-14/',
 'apr23':'https://www.nasa.gov/blogs/stationreport/2013/04/23/iss-daily-summary-report-04-23-13/',
 'apr26':'https://www.nasa.gov/blogs/stationreport/2013/04/26/iss-daily-summary-report-04-26-13/',
 'may15':'https://www.nasa.gov/blogs/stationreport/2013/05/15/iss-daily-summary-report-05-15-2013/',
 'june3':'https://www.nasa.gov/blogs/stationreport/2013/06/03/iss-daily-summary-report-06-03-13/'}
REPORT='https://ntrs.nasa.gov/api/citations/20210011385/downloads/TM-20210011385.pdf'
MATERIAL_SOURCE='https://www.nasa.gov/wp-content/uploads/2025/07/burning-and-suppression-of-solids-bass.pdf?emrc=3a5c2c'
D['date_session_reference']='';D['date_verification']='source_consistent';D['date_basis']='Selected date for analysis; GMT is calculated day of year, not independent validation.'
for i,r in D.iterrows():
 f=r.date_quality_flag; a=r.x_as_run_id; k=r.x_test_id; pid=r.investigation_id
 if f=='consistent': continue
 if f=='format_normalized': D.at[i,'date_verification']='format_corrected'; continue
 if f=='year_typo_corrected': status='year_typo_session_supported'; ev='Workbook GMT-13 135 and surrounding rows establish 2013; NASA reports BASS operations May 15, 2013.'; url=links['may15']
 elif pid=='PSI-26' and a=='93': status='date_selected_workbook_supported';ev='Workbook 2013 actual/video dates and adjacent rows support Apr 26; NASA Apr 23 reports next session planned for Friday Apr 26, but Apr 26 report does not independently identify this test. Alternative Apr 23 retained in audit.';url=links['apr23']+'; '+links['apr26']
 elif pid=='PSI-26' and a=='111':status='date_selected_session_supported';ev='GMT 137 and neighbouring workbook runs support May 17; NASA reports BASS operations that day. Exact test ID not reported.';url=links['may17']
 elif pid=='PSI-26' and a in ['112','113','114','115','116']:status='date_selected_session_supported';ev='Five workbook timestamps share GMT 150; NASA reports BASS session May 30. June 3 report lists Saturday BASS sample locate, not named flame runs. Exact test IDs not reported.';url=links['may30']+'; '+links['june3']
 elif pid=='PSI-25' and k in ['T9','T18']:status='year_corrected_session_supported';ev='PI sheet GMT 2014 header, day 175 and NASA June 24 2014 report describing 2 cm cotton-fiberglass flame tests support year correction. Individual IDs not listed.';url=links['june24']
 elif pid=='PSI-25' and k=='O10':status='corrected_from_NASA_run_table';ev='NASA/TM-20210011385 Table A.5 lists O10, as-run 95, sample 210m, July 22 2014, GMT 203, 13:26. This resolves the source GMT mismatch at the individual run level.';url=REPORT
 else: raise ValueError(r.to_dict())
 D.at[i,'date_quality_flag']=status;D.at[i,'date_verification']=status;D.at[i,'date_evidence']=ev;D.at[i,'date_session_reference']=url
D['x_date_quality_flag']=D.date_quality_flag
for c in ["date_raw","date_excel_raw","date_corrected","gmt_day_raw","gmt_day","date_basis","date_evidence","date_alternative","date_excel_time_raw"]: D["x_"+c]=D[c]
# Source-backed classification of previously unclassified BASS sample descriptions.
D['x_material_family_analysis']=D.x_material_family_context
D['x_material_reference']=''
unknown=D.investigation_id.eq('PSI-26') & D.x_material_family_context.eq('Unclassified')
sphere=unknown & D.x_material_raw.str.contains('sphere',case=False)
ultem=unknown & D.x_material_raw.str.contains('ultem',case=False)
assert sphere.sum()==30 and ultem.sum()==2
D.loc[sphere,'x_material_family_context']='PMMA';D.loc[sphere,'x_material_basis']='NASA_BASS_design_sphere_geometry'
D.loc[ultem,'x_material_family_context']='Ultem';D.loc[ultem,'x_material_basis']='explicit_Ultem_source_label'
D.loc[unknown,'x_material_reference']=MATERIAL_SOURCE
D['x_material_family_analysis']=D.x_material_family_context
assert D.x_material_family_analysis.ne('Unclassified').all()
# The NASA report contains pre-calibration readings missing from the supplied CSV.
# A missing initial or final instrument observation invalidates the apparent calibrated pair.
D['x_o2_uncalibrated_initial_report']='';D['x_o2_uncalibrated_final_report']='';D['x_o2_report_source']='';D['x_oxygen_issue_basis']=''
for test,ini,fin,table in [('B2','20.6','','A.1'),('P22A','20.2','','A.3'),('P22B','','19.1','A.3'),('T28A','19.8','','A.6'),('T28B','','19.7','A.6')]:
 mask=D.investigation_id.eq('PSI-25') & D.x_test_id.eq(test)
 assert mask.sum()==1
 D.loc[mask,'x_o2_uncalibrated_initial_report']=ini;D.loc[mask,'x_o2_uncalibrated_final_report']=fin;D.loc[mask,'x_o2_report_source']=REPORT+' Table '+table
 D.loc[mask,'x_oxygen_issue_basis']='NASA report lacks '+('initial' if not ini else 'final')+' uncalibrated O2; reported calibrated pair is not a defensible measurement pair.'
D['date']=D.date_corrected
D['date_usable_for_chronology']='true'
# Screen legacy numeric fields too; preserve exact source fields separately.
review=D.x_oxygen_review.str.lower().eq('true')
D['x_oxygen_final_status']='not_available';is25=D.investigation_id.eq('PSI-25')
D.loc[is25,'x_oxygen_final_status']='accepted';D.loc[is25&D.x_oxygen_pct_final.eq(''),'x_oxygen_final_status']='not_reported';D.loc[review,'x_oxygen_final_status']='excluded_suspect_sensor_reading'
D['x_oxygen_pct_final_reported']=D.x_oxygen_pct_final;D['x_o2_change_pp_reported']=D.x_o2_change_pp
D.loc[review,['x_oxygen_pct_final','x_o2_change_pp']]='';D.loc[review,'x_o2_pair_review']='excluded_suspect_sensor_reading'
D['notes']=D.notes.str.replace('Suspicious O2 change; exclude from paired summary pending review','Reported final O2 rejected for quantitative analysis; no verified replacement',regex=False)
for legacy,feature in [('x_co_initial_ppm','x_co_initial'),('x_co_final_ppm','x_co_final'),('x_co2_initial_pct','x_co2_initial'),('x_co2_final_pct','x_co2_final')]:
 D[legacy]=D[feature+'_valid_value']
# Legacy columns that are used for the analysis now have the screened values.
D=D.sort_values('date_corrected',kind='stable'); idx=D.set_index('run_id')
for path in [T/'dashboard_runs.csv',T/'dashboard_runs_enriched.csv',E/'run_features.csv',*T.glob('PSI-*/tables/*runs_clean.csv'),*T.glob('PSI-*/tables/run_features.csv')]:
 old=read(path); new=idx.loc[old.run_id].reset_index();cols=list(old.columns)
 extra=['date','date_verification','date_session_reference','date_usable_for_chronology','x_oxygen_final_status','x_oxygen_pct_final_reported','x_o2_change_pp_reported','x_o2_uncalibrated_initial_report','x_o2_uncalibrated_final_report','x_o2_report_source','x_oxygen_issue_basis','x_material_family_analysis','x_material_reference']
 if 'flow_speed_value' in cols: extra += [c for c in D if re.match(r'x_(co|co2)_(initial|final)_(status|valid_value|lower_bound)$',c)]
 write(new[list(dict.fromkeys(cols+extra))].sort_values('date',kind='stable'),path)
cols=['investigation_id','run_id','source_file','source_row','x_secondary_row','date_raw','date_excel_raw','date_corrected','gmt_day_raw','gmt_day','date_quality_flag','date_evidence','date_alternative','date_session_reference','date_verification']
for pid,g in D.groupby('investigation_id'):
 folder=next(p for p in T.glob(pid+'_*') if p.is_dir());write(g[cols],folder/'tables/date_audit.csv');write(g[g.date_quality_flag.ne('consistent')][cols],folder/'tables/date_review.csv');write(g[cols],T/f'{pid}_chronology.csv')
write(D[D.date_quality_flag.ne('consistent')][cols],T/'date_review.csv')
g=D[is25.reindex(D.index)]; q=D.loc[review.reindex(D.index)]; p25=T/'PSI-25_bass-ii/tables';write(q[['run_id','source_file','source_row','x_secondary_row','x_test_id','x_oxygen_pct_initial','x_oxygen_pct_final_reported','x_oxygen_pct_final','x_oxygen_final_status','x_o2_uncalibrated_initial_report','x_o2_uncalibrated_final_report','x_o2_report_source','x_oxygen_issue_basis']],p25/'oxygen_review.csv')
issues=[]
for r in g.itertuples():
 if r.x_oxygen_final_status!='accepted':issues.append(dict(run_id=r.run_id,field='final_O2_pct',reported=r.raw_calibrated_final_o2_by_vol,usable=r.x_oxygen_pct_final,status=r.x_oxygen_final_status,source_row=r.source_row,secondary_row=r.x_secondary_row))
 for k in ['x_co_initial','x_co_final','x_co2_initial','x_co2_final']:
  s=getattr(r,k+'_status')
  if s!='numeric':issues.append(dict(run_id=r.run_id,field=k,reported=getattr(r,k+'_raw'),usable='',status=s,source_row=r.source_row,secondary_row=r.x_secondary_row))
write(pd.DataFrame(issues),E/'measurement_quality_audit.csv')
for pid,group in D.groupby('investigation_id'):
 folder=next(p for p in T.glob(pid+'_*') if p.is_dir()); tabs=folder/'tables'
 group.groupby('x_material_family_analysis').size().rename('records').to_csv(tabs/'material_counts_context.csv')
 pd.crosstab(group.x_material_family_keyword,group.x_material_family_analysis).to_csv(tabs/'material_context_crosswalk.csv')
write(D[['investigation_id','run_id','source_row','x_material_raw','x_material_family_keyword','x_material_family_analysis','x_material_basis','x_material_reference']],E/'material_classification_audit.csv')
# Dedicated clean-only table for downstream ingestion (no legacy/raw values).
viewcols=['investigation_id','run_id','source_file','source_row','x_test_id','date','gmt_day','date_verification','date_session_reference','x_material_family_analysis','x_material_basis','oxygen_pct','pressure_kpa','flow_speed_value','flow_speed_unit','x_oxygen_pct_final','x_oxygen_final_status','x_o2_change_pp','x_o2_pair_review']+[c for c in D if re.match(r'x_(co|co2)_(initial|final)_(status|valid_value|lower_bound)$',c)]
write(D[viewcols],T/'dashboard_runs_analysis_ready.csv')
summary='250 selected dates match their computed GMT day (zero arithmetic mismatches). Source reconciliation: sequence 42 format; sequence 104 year 2013; sequence 93 Apr 26 / 116 supported by workbook and scheduled session; sequence 111 May 17 / 137 and sequences 112–116 May 30 / 150 supported by NASA session reports; T9/T18 June 24 2014 / 175 supported by sheet header and NASA fabric tests; O10 July 22 2014 / 203 confirmed by the individual O10 record in NASA/TM-20210011385 Table A.5. Other daily reports establish sessions, not individual run IDs. Operational dates are selected, with alternatives preserved in the separate date audit. No claim of independent per-run confirmation.'
quality='NASA/TM-20210011385 Appendix A (Tables A.1, A.3, A.6) shows missing underlying O2 readings for B2, P22A, P22B, T28A, T28B. Their five reported final O2 readings are excluded from the analytical final O2 and change fields; two other final O2 readings are not reported. There are 122 usable pairs. Negative CO, nonnumeric and overrange readings are not exact concentrations; explicit censoring bounds remain. Raw source values and audit records are retained outside the primary RAG run fields. No fabricated replacements.'
# Make retrieval-facing chunks use analytical fields, not conflicting legacy values.
raw=(T/'Amr_BASS_Deep_Analysis_v6_clean.txt').read_text(); parts=re.split(r'(?=^\[CHUNK )',raw,flags=re.M); output=[];seen=[]
for c in parts:
 if c.startswith('[CHUNK T1-DATE-AUDIT]'): c='[CHUNK T1-DATE-AUDIT] Selected chronology and evidence\n'+summary+'\nSources: '+'; '.join(links.values())+'\n\n'
 if c.startswith('[CHUNK T1-25-04]'):c='[CHUNK T1-25-04] BASS-II screened paired oxygen\n[CALC S7; S5] 122 usable complete pairs; median final minus initial -0.300 percentage points; mean -0.486. '+quality+'\nSource: PSI-25_BASS-II_raw.csv; audit source rows 3,97,98,128,129.\n\n'
 m=re.search(r'^\[CHUNK T1-(25|26)-RUN-[^\]]+\].*?\| run (.+)$',c,re.M)
 if m:
  r=idx.loc[m.group(2).strip()];seen.append(r.name)
  line=f'[CALC date audit] date: {r.date_corrected}; gmt_day: {r.gmt_day}; date_verification: {r.date_verification}.'
  if r.date_session_reference:line+=' Evidence: '+r.date_evidence+' Sources: '+r.date_session_reference
  c=re.sub(r'^\[CALC date audit\].*$',lambda _:line,c,flags=re.M)
  c=re.sub(r'^material_family_context:.*$',lambda _: 'material_family_context: '+r.x_material_family_context+'; basis: '+r.x_material_basis+(('; source: '+r.x_material_reference) if r.x_material_reference else ''),c,flags=re.M)
  c=re.sub(r'^material_or_fuel:.*$',lambda _: 'material_or_fuel: '+r.x_material_family_analysis+'; source keyword classification: '+r.x_material_family_keyword,c,flags=re.M)
  if r.x_oxygen_issue_basis: c=c.rstrip()+'\n[Measurement audit] '+r.x_oxygen_issue_basis+' Uncalibrated initial O2: '+(r.x_o2_uncalibrated_initial_report or 'not reported')+'; uncalibrated final O2: '+(r.x_o2_uncalibrated_final_report or 'not reported')+'. Not a calibrated pair. Source: '+r.x_o2_report_source+'\n\n'
  if m.group(1)=='25':
   for field in ['x_oxygen_pct_final','x_co_initial_ppm','x_co_final_ppm','x_co2_initial_pct','x_co2_final_pct']:
    c=re.sub(r'^'+field+r':.*$',lambda _:field+': '+(r[field] or 'not available for quantitative use'),c,flags=re.M)
   c=re.sub(r'^x_oxygen_review:.*$', 'final_oxygen_quality: '+r.x_oxygen_final_status,c,flags=re.M)
   c=re.sub(r'^oxygen_change_pp:.*$',lambda _: 'oxygen_change_pp: '+(r.x_o2_change_pp or 'not available')+'; pair status: '+r.x_o2_pair_review,c,flags=re.M)
   for field in ['x_co_initial','x_co_final','x_co2_initial','x_co2_final']:
    c=re.sub(r'^'+field+r':.*$',lambda _:field+': exact='+ (r[field+'_valid_value'] or 'not available')+'; status='+r[field+'_status']+'; lower_bound='+(r[field+'_lower_bound'] or 'not applicable'),c,flags=re.M)
   c=c.replace('Suspicious O2 change; exclude from paired summary pending review','Reported final O2 rejected for quantitative analysis; no verified replacement')
 if c.startswith('[CHUNK T1-25-SENSITIVITY]'): c=c.replace('Oxygen review sensitivity','Historical screening sensitivity (diagnostic only)')+'Only the screened 122-pair result is suitable for the primary analytical set; other scenarios intentionally include rejected records and must not be presented as valid measurements.\n\n'
 if c.startswith('[CHUNK T1-V6-METHOD]'):c=c.replace('Review flag unchanged.','Screened values are authoritative; excluded values are retained in the measurement audit only.')
 c=c.replace('V5 exclusion leaves 122 pairs','Screened analytical set contains 122 pairs').replace('Cause of unusual readings unknown; values retained.','Suspect measurements excluded from the analytical layer; raw audit retained.')
 output.append(c)
assert len(seen)==250 and set(seen)==set(D.run_id)
combined=''.join(output); combined+='\n[CHUNK T1-26-MATERIAL-V7] Source-supported material classification\nNASA’s BASS investigation description identifies the 1 and 2 cm solid sphere fuels as PMMA and names Ultem as a thin fuel. In the supplied BASS test table, 30 previously unclassified sphere records are assigned PMMA and two explicit Ultem records are assigned Ultem. Contextual counts: 78 PMMA, 23 Wax, 12 SIBAL, 6 Nomex, 2 Ultem. The prior keyword-only statistics remain labelled as such; this is not a hazard ranking. Source: '+MATERIAL_SOURCE+'\n\n'; combined+='\n[CHUNK T1-25-QUALITY-V7] Measurement-use rule\n'+quality+'\n\n'; (T/'Amr_BASS_Deep_Analysis_v7_clean.txt').write_text(combined,encoding='utf-8')
for pid in ['25','26']:
 folder=next(p for p in T.glob('PSI-'+pid+'_*') if p.is_dir()); path=folder/'rag_corpus.txt'; old=path.read_text(); oldids=set(re.findall(r'^\[CHUNK ([^\]]+)\]',old,re.M)); selected=[c for c in re.split(r'(?=^\[CHUNK )',combined,flags=re.M) if (m:=re.match(r'^\[CHUNK ([^\]]+)\]',c)) and (m.group(1) in oldids or (pid=='25' and m.group(1)=='T1-25-QUALITY-V7') or (pid=='26' and m.group(1)=='T1-26-MATERIAL-V7'))];path.write_text(old.split('[CHUNK ',1)[0]+''.join(selected),encoding='utf-8')
# Refresh legacy wording where it referred to the old published state; leave raw/history untouched.
for f in [T/'HANDOFF.md',T/'VALIDATION.md',E/'test_questions.md',E/'limitations.md',E/'FEATURE_DICTIONARY.md',T/'SELF_CHECK.md']:
 s=f.read_text();s=re.sub(r'Date audit v4:.*?(?=\n|$)',summary,s);s=s.replace('nine provisional year/date/GMT choices including T9/T18','O10 individually confirmed by the NASA technical report; other selected dates have source/session evidence, not universal per-run confirmation').replace('B2 final oxygen 1.6 vs 22.2 initial retained but excluded from paired analysis; cause unconfirmed.',quality).replace('original video/log confirmation and human review remain pending','original video/log confirmation is unavailable; session-level evidence and scientific limitations are documented');f.write_text(s+'\nV7 publication: '+quality+'\n',encoding='utf-8')
(T/'DATE_VALIDATION.md').write_text(summary+'\n\n'+'\n'.join(f'{k}: {v}' for k,v in links.items())+'\n',encoding='utf-8')
with (T/'references.md').open('a') as f:f.write('\nNASA ISS Daily Summary Reports (session corroboration only)\n'+'\n'.join(links.values())+'\n' + REPORT+' (Appendix A individual run tables)\n'+MATERIAL_SOURCE+' (BASS sample design)\n')
# Validate after publication, not simply before screening.
assert len(D)==250 and D.date.is_monotonic_increasing and pd.to_datetime(D.date).dt.dayofyear.eq(D.gmt_day.astype(int)).all()
assert D.loc[review.reindex(D.index),'x_oxygen_pct_final'].eq('').all() and D.loc[review.reindex(D.index),'x_o2_change_pp'].eq('').all()
assert (g.x_oxygen_pct_final.ne('') & g.x_oxygen_pct_initial.ne('')).sum()==122
for col in ['x_co_initial_ppm','x_co_final_ppm','x_co2_initial_pct','x_co2_final_pct']:assert pd.to_numeric(D[col],errors='coerce').dropna().ge(0).all()
assert all(hashlib.sha256((R/'data'/n).read_bytes()).hexdigest()==h for n,h in json.loads((T/'raw_hashes.json').read_text()).items())
for p in T.glob('PSI-*/rag_corpus.txt'):
 pid=p.parent.name[4:6];s=p.read_text(); assert len(re.findall(r'^\[CHUNK T1-'+pid+r'-RUN-',s,re.M))==({'25':129,'26':121}[pid]);assert not re.search(r'^\[CHUNK T1-'+('25' if pid=='26' else '26')+r'-RUN-',s,re.M)
 assert not re.search(r'^x_co_(initial|final)_ppm: -',s,re.M);assert 'date_raw:' not in s;assert not re.search(r'^material_or_fuel: Unclassified',s,re.M)
for p in T.glob('Amr_BASS_Deep_Analysis_v6*.txt'):p.unlink()
report=summary+'\n\n'+quality+'\n\nPASS: 250 unique IDs; chronological dates; computed GMT equality; 122 usable oxygen pairs; no negative exact gas values; four unchanged raw SHA-256 hashes; 121/129 dataset RAG run chunks; zero unclassified contextual materials.'
(T/'V7_VALIDATION.txt').write_text(report+'\n',encoding='utf-8');print(report)
