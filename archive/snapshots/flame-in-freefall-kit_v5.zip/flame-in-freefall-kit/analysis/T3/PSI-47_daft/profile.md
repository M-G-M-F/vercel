# Profile: PSI-47 DAFT / DAFT-2

## Folders on PSI (from the PSI file listing; check against the page)

| Folder | Files | Size (MB, 1 MB = 1,048,576 bytes) |
| --- | --- | --- |
| Analyzed Data | 12 | 3.3 |
| Engineering Documents | 6 | 7.6 |
| Experimental table | 1 | 0.0 |
| Presentations | 3 | 14.4 |
| Raw Data | 6 | 0.0 |
| Reports | 3 | 13.3 |
| Representative Image(s) | 1 | 1.3 |
| metadata | 1 | 0.0 |

## Experimental table and downloaded files

Run from the kit root and paste or append the output here:

```bash
python tools/profile_files.py "data/experimental_tables/PSI-47" --out "analysis/T3/PSI-47_daft/profile.md"
python tools/profile_files.py "data/raw/PSI-47" --out "analysis/T3/PSI-47_daft/profile.md"   # after downloading
```

## Documents (PDF, presentations)

| File | Title | Pages | What it is for |
| --- | --- | --- | --- |
