# Profile: PSI-101 SAME-R

## Folders on PSI (from the PSI file listing; check against the page)

| Folder | Files | Size (MB, 1 MB = 1,048,576 bytes) |
| --- | --- | --- |
| Analyzed Data | 86 | 472.2 |
| Engineering Documents | 24 | 52.6 |
| Experimental table | 1 | 0.0 |
| Presentations | 4 | 31.8 |
| Raw Data | 223 | 5,453.5 |
| Reference Data | 2 | 0.6 |
| Reports | 1 | 4.4 |
| Science Documents | 2 | 0.9 |
| metadata | 1 | 0.0 |

## Experimental table and downloaded files

Run from the kit root and paste or append the output here:

```bash
python tools/profile_files.py "data/experimental_tables/PSI-101" --out "analysis/T3/PSI-101_same-r/profile.md"
python tools/profile_files.py "data/raw/PSI-101" --out "analysis/T3/PSI-101_same-r/profile.md"   # after downloading
```

## Documents (PDF, presentations)

| File | Title | Pages | What it is for |
| --- | --- | --- | --- |
