# Run order: PSI-101 SAME-R

Run every command from the kit root folder.

1. `python tools/build_run_table.py "analysis/T3/PSI-101_same-r/scripts/run_table_map.yaml"`

Add your own scripts below, in the order they must run.
