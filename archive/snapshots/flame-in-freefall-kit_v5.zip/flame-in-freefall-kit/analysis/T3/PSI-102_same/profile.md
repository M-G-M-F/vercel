# Profile: PSI-102 SAME

## Folders on PSI (from the PSI file listing; check against the page)

| Folder | Files | Size (MB, 1 MB = 1,048,576 bytes) |
| --- | --- | --- |
| Analyzed Data | 59 | 217.5 |
| Engineering Documents | 28 | 345.2 |
| Experimental table | 1 | 0.0 |
| Presentations | 6 | 58.6 |
| Reference Data | 3 | 1.3 |
| Reports | 1 | 3.5 |
| Science Documents | 2 | 0.9 |
| metadata | 1 | 0.0 |

## Experimental table and downloaded files

Run from the kit root and paste or append the output here:

```bash
python tools/profile_files.py "data/experimental_tables/PSI-102" --out "analysis/T3/PSI-102_same/profile.md"
python tools/profile_files.py "data/raw/PSI-102" --out "analysis/T3/PSI-102_same/profile.md"   # after downloading
```

## Documents (PDF, presentations)

| File | Title | Pages | What it is for |
| --- | --- | --- | --- |
