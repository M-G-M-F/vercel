# References (T3, Mahmoud Nadeem)

## NASA PSI records

- PSI-102 SAME, DOI 10.60555/gd4k-8h62, https://psi.nasa.gov/physci/repo/data/investigations/PSI-102 [replace this line with the text of 'Cite this Investigation' on the PSI page]
- PSI-101 SAME-R, DOI 10.60555/2np7-jv14, https://psi.nasa.gov/physci/repo/data/investigations/PSI-101 [replace this line with the text of 'Cite this Investigation' on the PSI page]
- PSI-47 DAFT / DAFT-2, DOI 10.60555/ztgj-d202, https://psi.nasa.gov/physci/repo/data/investigations/PSI-47 [replace this line with the text of 'Cite this Investigation' on the PSI page]

## Publications (every paper you read, with DOI)


## Software and tools

- Python and the open-source libraries in requirements.txt (pandas, NumPy, Matplotlib, SciPy, scikit-learn, openpyxl, xlrd, requests, PyYAML)
- Team kit tools, made by Mahmoud Nadeem with AI assistance (see si_log.md)

## Other sources (web pages, images)

