/* "Ask the crew": offline expert system (TF-IDF matching over saved questions, findings and FAQ),
   with an optional online answer service. Every offline answer cites the finding it comes from. */
(function () {
  const FIF = window.FIF, D = FIF.data;
  const cfg = Object.assign({ api_url: "", timeout_ms: 8000, min_score: 0.18 }, D.chat || {});
  const STOP = new Set("a an the of to in on for and or is are was were be been it its this that these those what which who how why when where do does did can could would should will i you we they me my your our about with from by as at than then there here into out up down not no yes any some more most much many very just also only so if but".split(" "));
  const stem = (w) => w.length > 4 ? w.replace(/(ing|ed|es|s)$/, "") : w;
  // everyday words -> the words used in the findings (applied to questions and to the knowledge base)
  const SYN = {};
  [["size", "big", "bigger", "biggest", "large", "larger", "largest", "small", "smaller", "smallest", "tiny", "diameter", "grow", "grew", "growth", "nm", "um"],
   ["age", "aging", "ageing", "aged", "time", "later", "old", "older", "minute", "wait"],
   ["flow", "air", "airflow", "ventilation", "fan", "breeze", "wind", "velocity"],
   ["detector", "detection", "detect", "alarm", "sensor", "sense", "warning"],
   ["material", "plastic", "fabric", "teflon", "kapton", "silicone", "lampwick", "pyrell", "cotton", "foam"],
   ["smoke", "aerosol", "particle", "particulate", "soot"],
   ["heat", "heater", "hot", "hotter", "temperature", "warm", "overheat"],
   ["counter", "ptrak", "dustrak", "dusttrak", "instrument", "device"],
   ["moon", "lunar", "habitat", "mars", "oxygen", "pressure", "psi"]]
    .forEach((g) => g.forEach((w) => (SYN[stem(w)] = g[0])));
  const tokens = (s) => String(s || "").toLowerCase().replace(/f-t\d+-\d+/g, " ").replace(/([a-z])-([a-z])/g, "$1$2")
    .split(/[^a-z0-9]+/).filter((w) => w && !STOP.has(w)).map(stem).map((w) => SYN[w] || w);

  // ---- knowledge items -------------------------------------------------------------
  function buildItems() {
    const items = [];
    (D.faq.items || []).forEach((f) => items.push({ owner: "guide", q: f.q, text: [f.q, f.q, (f.keywords || []).join(" "), (f.keywords || []).join(" "), f.a], a: f.a, source: f.source, refs: [] }));
    D.tracks.forEach((t) => {
      const ch = FIF.characterForTrack(t.id);
      if (!ch) return;
      const recs = t.records.map((r) => D.records[r]).filter(Boolean);
      const words = recs.map((r) => `${r.acronym} ${r.title}`).join(" ");
      items.push({ owner: "guide", route: ch.id, q: `Who covers ${recs.map((r) => r.acronym).join(", ")}?`,
        text: ["who studied covers responsible expert crew member", words, ch.name, ch.role, ch.role], a: `That is ${ch.name}'s area: ${ch.role}. Pick ${ch.name.split(" ")[0]} in the crew bar above to ask about it.`, refs: [] });
      items.push({ owner: ch.id, q: "What is your part about?", text: ["what is your part about track topic study experiment explain", t.paragraph || ch.role],
        a: t.paragraph || `${ch.role}. My findings are not in yet.`, refs: [] });
      if (t.limitations) items.push({ owner: ch.id, q: "What are the limits of your data?", text: ["limit limitation weakness caveat trust uncertain", t.limitations], a: t.limitations, refs: [] });
      recs.forEach((r) => items.push({ owner: ch.id, q: `What did ${r.acronym} do?`, text: [r.acronym, r.acronym, r.acronym, r.title, r.objectives, r.approach, "tell me about what did experiment do goal objective approach method"],
        a: (r.objectives ? r.objectives + " " : "") + (r.approach || "") || `${r.title}. Details are on its NASA PSI page.`, refs: [], link: `#/record/${r.id}` }));
    });
    D.questions.forEach((q) => { const ch = FIF.characterForTrack(q.track); if (ch) items.push({ owner: ch.id, q: q.q, text: [q.q, q.q, q.a], a: q.a, refs: q.findings || [] }); });
    D.tracks.forEach((t) => {
      const ch = FIF.characterForTrack(t.id); if (!ch) return;
      (t.snippets || []).forEach((s) => { const f = FIF.finding(s.id); items.push({ owner: ch.id, q: s.snippet, w: 1.1, text: [s.snippet, s.snippet, f ? f.statement : ""], a: s.snippet, refs: [s.id] }); });
    });
    D.findings.forEach((f) => { const ch = FIF.characterForTrack(f.track); if (ch) items.push({ owner: ch.id, q: null, w: 0.85, text: [f.statement, f.caveat], a: `${f.statement} Caveat: ${f.caveat}`, refs: [f.id] }); });
    // tf-idf vectors
    const docs = items.map((it) => tokens(it.text.join(" ")));
    const df = {}; docs.forEach((d) => new Set(d).forEach((w) => (df[w] = (df[w] || 0) + 1)));
    const N = docs.length, idf = (w) => Math.log((N + 1) / ((df[w] || 0) + 1)) + 1;
    const vec = (toks) => { const v = {}; toks.forEach((w) => (v[w] = (v[w] || 0) + 1)); let n = 0;
      for (const w in v) { v[w] *= idf(w); n += v[w] * v[w]; } n = Math.sqrt(n) || 1; for (const w in v) v[w] /= n; return v; };
    items.forEach((it, i) => (it.v = vec(docs[i])));
    return { items, vec };
  }
  let KB = null;
  const cos = (a, b) => { let s = 0; for (const w in a) if (b[w]) s += a[w] * b[w]; return s; };

  // "what did SAME-R do?" / "tell me about DAFT": answer with the experiment itself, not a single finding
  function recordIntent(question) {
    if (!/^\s*(what (did|does|is|was)|tell me (about|more)|explain|describe)\b/i.test(question)) return null;
    const q = " " + question.toLowerCase().replace(/[^a-z0-9-]+/g, " ") + " ";
    const hit = Object.values(D.records).filter((r) => r.acronym).map((r) => ({ r, keys: r.acronym.toLowerCase().split(/\s*\/\s*|\s+/).filter((k) => k.length > 2) }))
      .filter(({ keys }) => keys.some((k) => q.includes(" " + k + " ")))
      .sort((a, b) => Math.max(...b.keys.map((k) => k.length)) - Math.max(...a.keys.map((k) => k.length)))[0];
    return hit ? hit.r : null;
  }

  function answerOffline(question, who) {
    KB = KB || buildItems();
    const rec = recordIntent(question);
    if (rec) {
      const it = KB.items.find((x) => x.link === `#/record/${rec.id}`);
      const owner = FIF.characterForTrack(rec.track);
      if (it && (who === "guide" || owner.id === who)) {
        return { text: who === "guide" ? `${rec.acronym} is ${owner.name}'s experiment. ${it.a}` : it.a, refs: rec.findings.slice(0, 3), link: it.link, score: 1 };
      }
    }
    const qv = KB.vec(tokens(question));
    const pool = KB.items.filter((it) => who === "guide" ? true : it.owner === who || (it.owner === "guide" && !it.route));
    const ranked = pool.map((it) => ({ it, s: cos(qv, it.v) * (it.owner === who ? 1.15 : 1) * (it.w || 1) })).sort((a, b) => b.s - a.s);
    const best = ranked[0];
    if (!best || best.s < cfg.min_score) {
      return { text: "I can't answer that from our NASA data. Try one of the questions below, or ask the crew member who covers that experiment.", refs: [], miss: true };
    }
    const it = best.it, owner = FIF.character(it.owner);
    let text = it.a;
    if (who === "guide" && it.owner !== "guide") text = `${owner.name} found this: ${it.a}`;
    return { text, refs: it.refs, source: it.source, link: it.link, route: it.route, score: best.s };
  }

  async function answerOnline(question, who) {
    if (!cfg.api_url || !navigator.onLine) return null;
    const ch = FIF.character(who);
    KB = KB || buildItems();
    const qv = KB.vec(tokens(question));
    const context = KB.items.filter((it) => who === "guide" || it.owner === who).map((it) => ({ it, s: cos(qv, it.v) }))
      .sort((a, b) => b.s - a.s).slice(0, 6).map(({ it }) => ({ text: it.a, findings: it.refs }));
    const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), cfg.timeout_ms);
    try {
      const r = await fetch(cfg.api_url, { method: "POST", headers: { "Content-Type": "application/json" }, signal: ctl.signal,
        body: JSON.stringify({ question, character: ch.name, track: ch.track, context }) });
      if (!r.ok) return null;
      const j = await r.json();
      return j && j.answer ? { text: j.answer, refs: [...new Set(context.flatMap((c) => c.findings))].slice(0, 4), online: true } : null;
    } catch (e) { return null; } finally { clearTimeout(timer); }
  }

  // ---- UI -------------------------------------------------------------------------
  let current = "guide";
  const log = () => FIF.$("#chat-log");

  function refsHTML(a) {
    const parts = [];
    if (a.refs && a.refs.length) parts.push("Evidence: " + a.refs.map((id) => `<a href="#/research?q=${encodeURIComponent(id)}">${FIF.esc(id)}</a>`).join(", "));
    if (a.source) parts.push("Source: " + FIF.esc(a.source));
    if (a.link) parts.push(`<a href="${a.link}">Open the experiment</a>`);
    if (a.online) parts.push("Online AI answer: check the cited findings.");
    return parts.length ? `<div class="refs">${parts.join(" &middot; ")}</div>` : "";
  }

  // A message slot is created the moment a greeting or question is requested, so the log
  // keeps request order even while earlier crew members are still talking.
  function slot(speaker, note) {
    const ch = FIF.character(speaker);
    const el = document.createElement("div");
    el.className = "msg bot is-queued";
    el.innerHTML = `${FIF.spriteHTML(ch.id)}<div class="bubble"><span class="who">${FIF.esc(ch.name.toUpperCase())}</span><span class="t"><span class="wait-dots" aria-hidden="true">&#9646;&#9646;&#9646;</span> ${FIF.esc(note)}</span></div>`;
    el.dataset.speaker = ch.id;
    log().appendChild(el);
    const cv = el.querySelector("canvas"); if (cv) { cv.dataset.state = "waiting"; FIF.drawSprite(cv, ch.id); }
    log().scrollTop = log().scrollHeight;
    return el;
  }

  async function botSay(text, a = {}, speaker = current, el = null) {
    const ch = FIF.character(speaker);
    if (!el) el = slot(speaker, "");
    const bubble = el.querySelector(".bubble"), t = el.querySelector(".t"), cv = el.querySelector("canvas");
    el.classList.remove("is-queued", "is-waiting");
    el.classList.add("is-transmitting");
    t.textContent = "";
    if (refsHTML(a)) bubble.insertAdjacentHTML("beforeend", refsHTML(a));
    const typing = FIF.typeText(t, text, cv ? [cv] : [], ch.id);
    activeText = t;
    if (FIF.attachChatVisual) FIF.attachChatVisual(bubble, a, text);
    log().scrollTop = log().scrollHeight;
    if (a.route) {
      const b = document.createElement("button"); b.className = "chip"; b.type = "button"; b.textContent = `ASK ${FIF.character(a.route).name.split(" ")[0].toUpperCase()}`;
      b.onclick = () => select(a.route); bubble.appendChild(b);
    }
    await typing;
    el.classList.remove("is-transmitting");
    activeText = null;
    log().scrollTop = log().scrollHeight;
  }

  let activeText = null;
  const queue = FIF.createConversationQueue((pending, running) => {
    const status = FIF.$("#chat-queue-status");
    if (status) status.textContent = running ? (pending ? `${pending} waiting · one crew member at a time` : "Crew transmission in progress") : "Ready for your next question";
  });
  const enqueue = job => queue.add(job).catch(() => {
    const status = FIF.$("#chat-queue-status");
    if (status) status.textContent = "That transmission failed. You can try again.";
  });

  function suggestions() {
    KB = KB || buildItems();
    const qs = KB.items.filter((it) => it.owner === current && it.q && /\?$/.test(it.q)).map((it) => it.q);
    const box = FIF.$("#chat-suggest");
    box.innerHTML = "";
    qs.slice(0, 4).forEach((q) => { const b = document.createElement("button"); b.type = "button"; b.textContent = q.length > 70 ? q.slice(0, 68) + "..." : q;
      b.onclick = () => ask(q); box.appendChild(b); });
  }

  const greeted = new Set();
  function select(id) {
    if (id === current && log().children.length) return; // repeated clicks never repeat a greeting
    current = id;
    FIF.$$("#chat-crew button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.id === id)));
    const ch = FIF.character(id);
    const line = greeted.has(id) ? `${ch.name.split(" ")[0]} here again. What would you like to know?` : ch.greeting;
    greeted.add(id);
    const el = slot(id, "waiting to speak…");
    enqueue(() => botSay(line, {}, id, el));
    suggestions();
  }

  function ask(q) {
    q = q.trim(); if (!q) return;
    const speaker = current; // Capture the recipient before any asynchronous work.
    const u = document.createElement("div"); u.className = "msg user"; u.textContent = q; log().appendChild(u);
    const el = slot(speaker, "question received, waiting in line…");
    enqueue(async () => {
      const crewButton = FIF.$$("#chat-crew button").find(button => button.dataset.id === speaker);
      crewButton?.classList.add("is-waiting");
      el.classList.add("is-waiting");
      const t = el.querySelector(".t"); if (t) t.innerHTML = '<span class="wait-dots" aria-hidden="true">&#9646;&#9646;&#9646;</span> thinking…';
      try {
        const a = (await answerOnline(q, speaker)) || answerOffline(q, speaker);
        await botSay(a.text, a, speaker, el);
      } catch (error) {
        el.classList.remove("is-waiting", "is-queued"); el.classList.add("is-failed");
        if (t) t.textContent = "Transmission failed. Please ask again.";
        throw error;
      } finally {
        crewButton?.classList.remove("is-waiting");
        const cv = el.querySelector("canvas"); if (cv && cv.dataset.state === "waiting") cv.dataset.state = "idle";
      }
    });
  }

  FIF.openChat = function (id) {
    const panel = FIF.$("#chat"), launch = FIF.$("#chat-launch");
    panel.hidden = false; launch.hidden = true; launch.setAttribute("aria-expanded", "true");
    if (id && id !== current) select(id);
    else if (!log().children.length) select(current);
    FIF.$("#chat-input").focus();
  };

  FIF.initChat = function () {
    const status = document.createElement("p"); status.id = "chat-queue-status";
    status.className = "chat-mode"; status.setAttribute("role", "status");
    status.textContent = "Ready for your next question";
    const finish = document.createElement("button"); finish.className = "chip";
    finish.textContent = "SHOW FULL MESSAGE"; finish.type = "button";
    finish.onclick = () => activeText?._finishTyping?.();
    FIF.$("#chat").insertBefore(status, FIF.$("#chat-form"));
    FIF.$("#chat-suggest").after(finish);
    const crew = FIF.$("#chat-crew");
    crew.innerHTML = FIF.characters.map((c) => `<button type="button" role="tab" data-id="${FIF.esc(c.id)}" title="${FIF.esc(c.name)}: ${FIF.esc(c.role)}" aria-selected="false">${FIF.spriteHTML(c.id, "", c.name)}</button>`).join("");
    FIF.paintSprites(crew);
    crew.addEventListener("click", (e) => { const b = e.target.closest("button[data-id]"); if (b) select(b.dataset.id); });
    FIF.$("#chat-launch").addEventListener("click", () => FIF.openChat());
    FIF.$("#chat-close").addEventListener("click", () => { if (FIF.closeChat) { FIF.closeChat(true); return; } FIF.$("#chat").hidden = true; const l = FIF.$("#chat-launch"); l.hidden = false; l.setAttribute("aria-expanded", "false"); l.focus(); });
    FIF.$("#chat-form").addEventListener("submit", (e) => { e.preventDefault(); const i = FIF.$("#chat-input"); ask(i.value); i.value = ""; });
    FIF.$("#chat-mode").textContent = cfg.api_url ? "Online answers when connected; saved answers otherwise." : "Saved answers (works offline). Every answer cites its finding.";
  };
  FIF._answerOffline = answerOffline; // used by the self-test
})();
