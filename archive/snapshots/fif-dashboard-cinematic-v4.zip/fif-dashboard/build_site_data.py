#!/usr/bin/env python3
"""Build data/site-data.js for the dashboard from the team's track packages.

    python build_site_data.py --kit "../flame-in-freefall-kit"

--kit points at a folder that contains analysis/T1..T6 (Mohammed Tamer's package layout) and
data/psi_metadata/*.json (PSI records). Unzipped member packages (T3_nadeem_v1.zip, ...) can be
dropped into <kit>/analysis/ as they arrive; run this script again and refresh the page.

The site is opened straight from disk (file://), where browsers block fetch(), so everything the
pages need is written into ONE JavaScript file (window.FIF_DATA = {...}). Charts and data files that
a track ships are copied under data/files/<track>/ so the site never needs the internet.
"""
from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
TRACKS = {
    "T1": {"member": "morgan", "records": ["PSI-26", "PSI-25"]},
    "T2": {"member": "shreif", "records": ["PSI-98", "PSI-99", "PSI-100"]},
    "T3": {"member": "nadeem", "records": ["PSI-102", "PSI-101", "PSI-47"]},
    "T4": {"member": "tamer", "records": ["PSI-69", "PSI-68", "PSI-39", "PSI-159"]},
    "T5": {"member": "adwi", "records": ["PSI-20", "PSI-22", "PSI-23", "PSI-10"]},
    "T6": {"member": "gamal", "records": ["PSI-107", "PSI-106", "PSI-21", "PSI-60"]},
}
PAGE = "https://psi.nasa.gov/physci/repo/data/investigations/{}"


def read_json(p: Path, default=None):
    try:
        return json.loads(p.read_text(encoding="utf-8-sig"))
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def parse_findings(p: Path) -> list[dict]:
    """Lines 'F-T3-1 | statement | label | source | rows | confidence | caveat' (section 7.4)."""
    out = []
    if not p.exists():
        return out
    for line in p.read_text(encoding="utf-8").splitlines():
        if not line.startswith("F-"):
            continue
        parts = [x.strip() for x in line.split("|")]
        if len(parts) != 7:
            print(f"  skipped malformed finding in {p}: {line[:60]}")
            continue
        fid, statement, label, source, rows, confidence, caveat = parts
        kind = ("observed" if label.upper().startswith("OBSERVED") else
                "reported" if label.upper().startswith("REPORTED") else "inference")
        out.append(dict(id=fid, statement=statement, label=label, kind=kind, source=source, rows=rows,
                        confidence=confidence.lower(), caveat=caveat))
    return out


def parse_questions(p: Path) -> list[dict]:
    """extra/test_questions.md: numbered 'Q: ...' lines followed by 'A: ...' lines."""
    out, q, answerable = [], None, True
    if not p.exists():
        return out
    for line in p.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if s.lower().startswith("## not answerable"):
            answerable = False
        m = re.match(r"^\d+\.\s*Q:\s*(.+)$", s)
        if m:
            q = m.group(1)
            continue
        m = re.match(r"^A:\s*(.+)$", s)
        if m and q:
            out.append({"q": q, "a": m.group(1), "answerable": answerable,
                        "findings": re.findall(r"F-T\d+-\d+", m.group(1))})
            q = None
    return out


def parse_citations(p: Path) -> dict:
    out = {}
    if not p.exists():
        return out
    for line in p.read_text(encoding="utf-8").splitlines():
        m = re.match(r"^- (PSI-\d+): (.+?)(?: \(text of 'Cite this Investigation'.*\))?$", line.strip())
        if m:
            out[m.group(1)] = m.group(2)
    return out


def parse_publications(p: Path) -> list[str]:
    if not p.exists():
        return []
    text = p.read_text(encoding="utf-8")
    block = text.split("## Publications", 1)[1].split("\n## ", 1)[0] if "## Publications" in text else ""
    return [l[2:].strip() for l in block.splitlines() if l.startswith("- ")]


def captions(rec: Path) -> dict:
    p = rec / "charts" / "CAPTIONS.md"
    out = {}
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            m = re.match(r"^- ([\w\-]+\.png): (.+)$", line.strip())
            if m:
                out[m.group(1)] = m.group(2)
    return out


def t3_dataset(track_dir: Path) -> dict | None:
    """Compact per-test table for the interactive smoke charts (T3)."""
    p = track_dir / "PSI-101_same-r" / "tables" / "derived_same_results_flight_tests.csv"
    if not p.exists():
        return None
    rows = []
    with open(p, encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            try:
                d = float(r["mean_diam_um"] or 0)
            except ValueError:
                continue
            if d <= 0 or r.get("size_consistent") == "False":   # no size, or a size row the T3 analysis keeps out (F-T3-23)
                continue
            num = lambda k: (round(float(r[k]), 4) if r.get(k) not in ("", None) else None)
            rows.append({"mission": r["mission"], "material": r["material"], "test": r["same_no"],
                         "parent": r["parent_test"], "aged": r["aged_measurement"] == "True",
                         "flow": num("vel_cm_s"), "rt": num("rt_r0"), "temp": num("sample_temp_c"),
                         "aging_s": num("net_aging_s"), "d_um": round(d, 4), "row": int(r["source_row"])})
    return {"id": "same_tests", "title": "SAME and SAME-R flight tests with a consistent particle size",
            "source": "PSI-101/Analyzed Data/PSI-101_Analyzed Data_SAME, SAME-R_Results.xlsx, sheet 'Reduced Data with ISS Det'",
            "materials": ["Kapton", "Teflon", "Lampwick", "Pyrell", "Silicone"], "rows": rows}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--kit", type=Path, default=HERE.parent / "flame-in-freefall-kit")
    args = ap.parse_args()
    kit = args.kit.resolve()
    files_dir = HERE / "data" / "files"   # files are overwritten in place (nothing is deleted)
    content = {n: read_json(HERE / "content" / f"{n}.json", {}) for n in ("project", "characters", "faq", "chat")}

    tracks, records, findings, questions, datasets = [], {}, [], [], {}
    for tid, t in TRACKS.items():
        tdir = kit / "analysis" / tid
        has_pkg = any((tdir / d).is_dir() and (tdir / d / "findings.md").exists() for d in
                      [p.name for p in tdir.glob("PSI-*")]) if tdir.exists() else False
        cites = parse_citations(tdir / "references.md")
        extra = tdir / "extra"
        tr = {"id": tid, "member": t["member"], "records": t["records"], "ready": False,
              "paragraph": (extra / "track_paragraph.md").read_text(encoding="utf-8").split("\n", 2)[-1].strip()
              if (extra / "track_paragraph.md").exists() else "",
              "limitations": (extra / "limitations.md").read_text(encoding="utf-8").split("\n", 2)[-1].strip()
              if (extra / "limitations.md").exists() else "",
              "snippets": read_json(extra / "evidence_snippets.json", []),
              "publications": parse_publications(tdir / "references.md"), "charts": []}
        for inv in t["records"]:
            meta = read_json(kit / "data" / "psi_metadata" / f"{inv}.json", {}) or {}
            recdir = next(iter(sorted(tdir.glob(f"{inv}_*"))), None) if tdir.exists() else None
            card = read_json(recdir / "card.json", {}) if recdir else {}
            rec_f = parse_findings(recdir / "findings.md") if recdir else []
            for f in rec_f:
                f.update(track=tid, record=inv)
            findings += rec_f
            caps = captions(recdir) if recdir else {}
            for png in sorted((recdir / "charts").glob("*.png")) if recdir else []:
                dst = files_dir / tid / png.name
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(png, dst)
                tr["charts"].append({"record": inv, "file": f"data/files/{tid}/{png.name}",
                                     "caption": caps.get(png.name, png.stem.replace("_", " "))})
            records[inv] = {
                "id": inv, "track": tid,
                "title": card.get("title") or meta.get("title") or inv,
                "acronym": card.get("acronym") or meta.get("acronym") or "",
                "doi": card.get("doi") or meta.get("doi") or "",
                "license": card.get("license") or meta.get("license") or "",
                "version": card.get("version", ""), "size": card.get("size_on_page", ""),
                "objectives": card.get("objectives") if card.get("objectives", "").strip() and "TODO" not in card.get("objectives", "") else "",
                "approach": card.get("approach") if card.get("approach", "").strip() and "TODO" not in card.get("approach", "") else "",
                "start": meta.get("start_date", ""), "end": meta.get("end_date", ""),
                "platform": meta.get("platform", ""), "sub_area": card.get("sub_research_area") or meta.get("sub_area", ""),
                "publications": card.get("publications") or [{"title": p.get("title", ""), "link": f"https://doi.org/{p['doi']}" if p.get("doi") else ""}
                                                             for p in meta.get("publications") or []],
                "citation": cites.get(inv, ""), "page": PAGE.format(inv),
                "findings": [f["id"] for f in rec_f], "verified": bool(card.get("verified_by")),
            }
        tr["ready"] = has_pkg and bool([f for f in findings if f["track"] == tid])
        for q in parse_questions(extra / "test_questions.md"):
            q["track"] = tid
            questions.append(q)
        if tid == "T3":
            ds = t3_dataset(tdir)
            if ds:
                datasets[ds["id"]] = ds
        tracks.append(tr)
        print(f"{tid}: {'package' if tr['ready'] else 'no package yet'}, "
              f"{sum(1 for f in findings if f['track'] == tid)} findings, {len(tr['charts'])} charts")

    findings.sort(key=lambda f: (f["track"], int(re.sub(r"\D", "", f["id"].split("-")[-1]) or 0)))
    data = {"built": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"), **content,
            "tracks": tracks, "records": records, "findings": findings, "questions": questions,
            "datasets": datasets}
    out = HERE / "data" / "site-data.js"
    out.parent.mkdir(exist_ok=True)
    out.write_text("/* generated by build_site_data.py - do not edit */\nwindow.FIF_DATA = "
                   + json.dumps(data, ensure_ascii=False, separators=(",", ":")) + ";\n", encoding="utf-8")
    print(f"wrote {out.relative_to(HERE)} ({out.stat().st_size / 1024:.0f} KB): {len(records)} records, "
          f"{len(findings)} findings, {len(questions)} questions, {len(datasets)} datasets")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
