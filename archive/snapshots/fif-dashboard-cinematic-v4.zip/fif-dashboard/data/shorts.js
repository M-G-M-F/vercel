/* Mission documents shown one at a time in the discovery viewport. These are original PDFs:
   two NASA documents and one project figure. They are documents, not a Shorts video collection. */
window.FIF_SHORTS = [
 {
  "id": "daft-facts",
  "title": "DAFT: instruments in microgravity",
  "url": "data/shorts/daft-facts.pdf",
  "source": "PSI-47 DAFT fact sheet (NASA PSI repository, Presentations folder)",
  "kind": "NASA DOCUMENT"
 },
 {
  "id": "daft-report",
  "title": "DAFT: flight observations",
  "url": "data/shorts/daft-report.pdf",
  "source": "PSI-47 DAFT 30-day post-flight report (NASA PSI repository, Reports folder)",
  "kind": "NASA DOCUMENT"
 },
 {
  "id": "envelope",
  "title": "Research: atmosphere coverage",
  "url": "data/shorts/envelope.pdf",
  "source": "Team analysis figure: atmosphere coverage of the experiments (reports/envelope.pdf)",
  "kind": "PROJECT FIGURE"
 }
];
