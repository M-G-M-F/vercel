# Flame in Freefall — cinematic universe, 15 November 2026 (v4)

Direction: the universe looks realistic, the interface feels like a game. Navigation is spatial
(fly to a world, travel back) instead of tabs. Scientific content, routes and research features are
unchanged; the original Retro look stays available.

## References

- Video 1 (rs69.dev, supplied recording, watched frame by frame): nebula and a large lit planet behind
  centred display type; content reveals as you scroll; each project is a celestial object that sits on
  alternating sides with its card and an ENTER button. Used for the Briefing scroll story.
- Video 2 (seunghyuk.com, supplied recording): a hub with labelled spokes that sway with the cursor and
  carry travelling dots; a 3D constellation of labelled nodes; a horizontal-line transition between
  scenes; side cues ("< MAIN", "PORTFOLIO >"); a sound toggle in words. Used for the mission map, the
  scanline route transition, the edge navigation and the toggles.
- airshifumi.hands.agency (opened in the in-app browser): layered foreground/background parallax and a
  slow title reveal. Informed the depth layers (far sky, near dust, worlds, interface).
- The Pinterest pin could not be retrieved (robots disallowed). Nothing here claims to match it.

## What changed

1. **Universe engine** (`assets/js/space-engine.js`, new). One persistent WebGL1 canvas behind every
   page: procedural nebula rendered to a low-resolution buffer and re-rendered only when the view
   changes; 2,600 far stars and 520 near dust points for parallax; a mission star with limb darkening and
   a restrained corona; six worlds and 20 experiment moons drawn as lit sphere impostors with 3D noise
   surfaces (ocean world with clouds and specular sea, desert with canyons, banded gas giant with a storm,
   fractured ice moon, volcanic world whose fissures glow on the night side, cratered moon), axial
   rotation independent of orbits, atmospheric rims and halos, light from the star. The camera drifts
   slowly, follows the pointer slightly, responds to scroll, and travels between scenes with
   interruptible tweens. Resolution is capped (DPR ≤ 1.5) and lowered automatically when frames are
   slow. Rendering stops while the tab is hidden. Retro view renders the same scene at low resolution
   with posterised colour over the original pixel starfield. Without WebGL a 2D canvas takes over.
2. **Briefing** is a scroll story: hero over a world, the "why", the guide (who starts talking when you
   reach him), then each world flies past on alternating sides with its scientist, experiments,
   publication status and ENTER WORLD, then the route.
3. **Explore is the mission map.** Accessible buttons follow the worlds; orbits, network spokes with
   travelling pulses and game reticles are drawn on an overlay. Hover or focus previews a compact card
   beside the world (placed away from the star); click approaches: the camera flies in, the interface
   fades, then the profile route opens with the camera already there. Hover, focus and preview stop
   orbital motion. Drag empty space to orbit the system; arrow keys move between worlds; touch selects
   on first tap and approaches on the second; phones get a focused selector with PREV/NEXT and swipes.
   The crew directory remains below as the no-animation alternative.
4. **Profile = landing deck.** The world fills the right side; the scientist's panel lists the
   experiments as moons. Hovering or focusing an experiment marks its moon in orbit, the scientist turns
   and points, and the line reports that experiment's real number of findings.
5. **Travel and history.** Every route maps to a camera scene (record and lab pull back from the owner's
   world). URLs are normal hashes. Returning to Explore restores the selected world, camera angle,
   orbit pause, scroll position and open details; the guide offers to continue to the next world once.
6. **Game controls.** `hud-btn` with hover, focus, pressed depth, selected and disabled states; console
   corners and telemetry; edge cues to the previous/next journey stop; scanline route entry.
7. **Characters.** States idle (big sprites float), speaking (only the speaker moves its mouth),
   waiting (visor scan), done (nod); blinking; eyes and pointing arm follow `look`. Reactions are tied
   to events: selecting or returning on the map, hovering an experiment, changing a lab parameter
   (with the calculated pulse position). `CREW: QUIET` turns them off.
8. **Crew conversation.** A message slot appears the moment a greeting or question is requested, so
   the log keeps request order while earlier messages are still typing; one speaker at a time; the
   recipient is captured at submission; a failed request marks its own slot and the queue continues;
   switching back to a character says a short "here again" instead of repeating the greeting.
9. **Answer visuals.** Answers citing F-T3-1, F-T3-2 or F-T3-3/4/5 can open a MEASURED view built from
   the same flight-test rows as the Results page. Transport answers (F-T3-16/17/20) can open the
   CALCULATED transport view. Each view is labelled measured or calculated.
10. **Lab model card**: model, purpose, parameters with units and bounds (from the validation schema),
    equation, assumptions, limitations, calibration status (not calibrated) and the AI's role.
11. **Document viewport.** PDF.js 6.5.438 is bundled (no CDN). Frame, PREVIOUS/NEXT, counter, page,
    zoom, fit width, keyboard (arrows, PageUp/Down, +/−), swipes on the frame only, loading percentage,
    error fallback, accessible page text and download. The three files are labelled as two NASA
    documents and one project figure, not as Shorts.

## Science boundaries

The universe is illustrative: fictional worlds stand for research tracks. Measured values come only
from the NASA tables (Results, Research, MEASURED views). The lab's 1-D advection–diffusion model is an
educational transport lesson; it is not calibrated to the SAME/SAME-R hardware and predicts no detector
response or alarm. The offline assistant matches saved questions and parses bounded lab commands; no
model produces numbers.

## Verification

Node tests (no browser), all passing: `planet`, `conversation`, `lab-config`, `expedition` (routes,
model card, bundled PDF.js, local assets), `scene-lifecycle` (mission map: selection, keyboard, hover
stabilisation, touch select-then-approach, navigation, cleanup, restored view, one return reaction) and
`universe` (2D fallback, body graph, world framing on both sides, home keyframes, map framing,
reduced-motion travel).

Browser test (`tests/browser.e2e.cjs`, Chromium with SwiftShader WebGL), passing: WebGL running;
hovered world holds still; hover preview; click approach and navigation; back restores the world and the
guide's return line; no frame callbacks accumulate over repeated route changes; lab reaction uses the
actual airflow; one speaker at a time; answer keeps its recipient after switching; view switch keeps the
lab value and the conversation; Escape closes the panel; PDF.js renders locally; rapid document changes
settle; no page errors; phone tap approaches; reduced motion keeps worlds still.

Also checked by screenshots: desktop and phone layouts, Retro view, 2D fallback (`--disable-webgl`),
file:// opening (universe works, PDFs fall back to the browser viewer). Not verified: real-GPU frame
rate, Safari and Firefox, real touch hardware, screen readers.

## Open points

- The DAFT fact sheet is an original NASA document and shows the NASA insignia inside the viewer. The
  competition asks teams not to use NASA logos; decide whether to keep the document, show only its
  first page text, or link to it instead.
- Members' own pixel portraits (with consent) can replace the generated astronauts.
