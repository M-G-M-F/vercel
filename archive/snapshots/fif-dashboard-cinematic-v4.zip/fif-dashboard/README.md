# Flame in Freefall dashboard

NASA's microgravity fire experiments explained for everyone, with a detailed view for researchers.
Concept and feature list: Mahmoud Nadeem (team). Built on the team's track packages (Mohammed Tamer's
package standard). The universe looks real; the interface feels like a game; every finding is traced
to its NASA source. See EVOLUTION.md for what changed, how it was tested and the scientific limits.

## Run it (no internet, no install)

Open `index.html` in Chrome, Edge or Firefox (double-click). Everything is local: pages, the universe,
charts, characters, saved answers, sources, fonts and the PDF viewer. Nothing is fetched from the internet.

Opened from disk, browsers block the PDF.js module, so mission documents show in the browser's own PDF
viewer. To get the in-site page, zoom and fit controls, serve the folder instead:

```bash
python -m http.server 8765      # then open http://localhost:8765
```

For a public link, upload the whole folder as a static site (GitHub Pages, Netlify, Cloudflare Pages).

## View modes

`VIEW: CINEMA` (default) shows the WebGL universe: nebula, stars, the mission star and six worlds.
`VIEW: RETRO` keeps the original pixel starfield and draws the same worlds as pixel art. Switching never
reloads, re-routes, resets the conversation or the lab. `MOTION OFF` (or the system's reduced-motion
setting) stops drift, rotation and travel; `CREW: QUIET` turns off character reactions; sound is off
until you press `SND`. Without WebGL the universe falls back to a 2D canvas.

## Update the data (after each member's package arrives)

1. Unzip the member's package (e.g. `T1_morgan_v1.zip`) into the kit, so that
   `flame-in-freefall-kit/analysis/T1/...` exists.
2. Run:
   ```bash
   python build_site_data.py --kit "../flame-in-freefall-kit"
   ```
3. Refresh the page.

The script reads, for every track: `card.json` (title, objectives, approach, citation check),
`findings.md` (the one-line finding format), `extra/evidence_snippets.json` (plain one-liners the
characters say), `extra/test_questions.md` (questions and answers the characters know),
`extra/track_paragraph.md`, `extra/limitations.md`, `references.md` and `charts/*.png` with
`charts/CAPTIONS.md`. It writes everything into `data/site-data.js` (one file, because browsers block
reading JSON files from disk) and copies charts to `data/files/`.

## Pages (the user journey)

| Route | What it is |
| --- | --- |
| `#/` Briefing | A scroll story: the camera flies past a world, the guide, then each crew world in turn |
| `#/explore` | The mission map: six worlds orbit the mission star; hover/focus previews, click approaches. Crew directory below |
| `#/profile/<id>` | Landing deck of one world: the scientist, their experiments as moons, notes |
| `#/record/<PSI-ID>` | One experiment: what they wanted to know, what they did, illustration, findings, charts |
| `#/lab/<PSI-ID>` | Transport lab (PSI-101, PSI-102, PSI-47) with a model card |
| `#/shorts` | Mission documents, one at a time, in the spacecraft viewport |
| `#/results` | Interactive charts that change with the chosen materials and flight; compare two experiments |
| `#/research` | Every finding with label, confidence, source file and exact rows; filters; CSV download |
| `#/sources` | Citations, PSI pages, DOIs, documents read, credits and AI disclosure |

### UI hooks (keep these names when restyling)

CSS can change anything. Scripts look up these IDs: in `index.html` `app`, `space`, `journey`, `footer`,
`motion-toggle`, `sound-toggle`, `edge-nav`, `hud-telemetry` and the `chat-*` IDs; inside page templates
(defined in the same script that uses them) the map (`map-*`), lab (`lab-*`), viewer (`pdf-*`, `short-*`)
and chart canvases (`c-size`, `c-aging`, `c-flow`). Renaming one means changing its script in the same commit.

## Characters and the chat

- `content/characters.json`: one character per member plus the guide (names, roles, greetings, colours).
- Built-in pixel astronauts are drawn in code. To use a member's own picture (with consent):
  `python tools/pixelate.py photo.jpg --id nadeem`, then paste the printed `sprite` and `mouth` into that
  character. The mouth box darkens while the character talks.
- Offline answers (default): an expert system matches the question against the guide's FAQ
  (`content/faq.json`), each track's questions and answers, evidence snippets, experiment summaries and
  findings. Every answer cites its finding ID. Unknown questions get "not in our data" plus suggestions.
- Optional online answers: set `api_url` in `content/chat.json` to an endpoint that holds the API key and
  returns `{"answer": "..."}`. If it is missing, slow (timeout) or offline, the saved answers are used.

## Interactive charts (T3 so far)

`assets/js/charts.js` draws the smoke charts from the SAME/SAME-R flight test table built from T3's
package. The two flights are never pooled (F-T3-5), and the air-flow chart compares within each heater
setting (pooling heater settings reverses the direction for Pyrell). New tracks add their own chart
functions the same way: a compact table in `build_site_data.py`, a draw function in `charts.js`, and a
section in `pages.js`.

## Files

```
index.html                    page shell (scripts load in order, no build step)
assets/css/style.css          original retro identity (palette, fonts, pixel buttons)
assets/css/expedition.css     universe layers, console chrome, story, map, deck, viewport, character states
assets/js/space-engine.js     WebGL universe: nebula, stars, star, worlds, camera scenes, 2D fallback
assets/js/planet-renderer.js  world definitions (palettes) + Canvas planet renderer used by the fallback
assets/js/starfield.js        retro pixel starfield (Retro view)
assets/js/orbital-explore.js  mission map (Explore)
assets/js/pages.js            briefing story, crew directory, record, results, research, sources
assets/js/expedition.js       profile deck, document viewport, crew panel closing
assets/js/lab.js, lab-config.js  transport model, lab page, validated command parser
assets/js/chat.js, conversation-queue.js, chat-visuals.js  crew chat, ordered queue, answer visuals
assets/js/sprites.js, dialog.js  pixel characters (idle, speaking, waiting, done, look, point), typewriter
assets/js/app.js              router, scene travel, edge navigation, toggles
assets/vendor/                Chart.js, PDF.js 6.5.438 (with licences)
data/site-data.js             generated by build_site_data.py
data/shorts.js, data/shorts/  mission documents (original PDFs)
tests/*.test.cjs              node tests (no browser); tests/browser.e2e.cjs needs Playwright
```

## Tests

```bash
for t in tests/*.test.cjs; do node "$t"; done                 # logic, lifecycle, camera framing
npm i -D playwright && npx playwright install chromium && node tests/browser.e2e.cjs   # real browser
```

## Credits

Chart.js (MIT), PDF.js 6.5.438 (Apache 2.0), Press Start 2P and VT323 fonts (SIL Open Font License), licences in `assets/`.
The universe is original procedural code (no copied images or textures); the worlds are fictional.
Data: NASA PSI repository (CC0). Code written with help from an AI assistant (Claude), disclosed on the
Sources page and in the team's AI-use logs.
