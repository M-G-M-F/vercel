# T3 extra work (section 9, done after the data work)

- test_questions.md: 5 questions the T3 data can answer and 2 it cannot, with answers (item 3).
- evidence_snippets.json: one-sentence evidence lines with finding ID, label, source file and rows, for the dashboard to cite (item 4).
- limitations.md: plain-English limitations paragraph for the project page (item 5).
- Demo chart (item 6): ../PSI-101_same-r/charts/aging_growth_by_material.png (no logo, no people; source in its caption).
- track_paragraph.md: the plain paragraph explaining the track (section 6), from Mahmoud's own summary.
