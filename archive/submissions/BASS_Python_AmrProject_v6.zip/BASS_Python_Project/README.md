# BASS / BASS-II — Morgan T1 V6

Python 3.10+ recommended. Open the project folder in VS Code or Cursor.

```sh
python -m pip install -r requirements.txt
python main.py
```

All four supplied raw tables and the metadata/FAQ are included. The pipeline writes to `output/analysis/T1/`. Source files are never overwritten.

Use `dashboard_runs.csv` for the V5-compatible view, `dashboard_runs_enriched.csv` for V6 features, and `PSI-25_bass-ii/rag_corpus.txt` and `PSI-26_bass/rag_corpus.txt` for dataset-specific retrieval. The combined V6 TXT is an alternative, not an additional corpus to ingest alongside both individual files. `deep_analysis_original.txt` is a historical input to the generator, not a final corpus.

Per-investigation run tables use the team schema (date columns now have `x_` prefixes). See `extra/FEATURE_DICTIONARY.md`, `extra/V6_CHANGES.md`, `extra/oxygen_sensitivity.csv`, `SELF_CHECK.md`, and `TEAM_SELF_CHECK.md`.

The supplied kit validator is bundled unchanged in `tools/`. V6 makes context-based material inference additive, screens negative/censored gas readings, and parses only complete numeric airflow strings. No safety threshold, validated outcome label, causal ranking, or ML model is claimed. Nine provisional dates/year choices and the PSI-26 oxygen/airflow units need source confirmation. Live NASA metadata, original videos and human approval are not verified. Retrieval questions are fixtures, not measured chatbot performance.
