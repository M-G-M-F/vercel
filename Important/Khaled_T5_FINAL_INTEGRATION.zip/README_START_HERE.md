# Khaled T5 — One-step integration handoff

**This archive is ONLY the T5 workstream**, not all teammates' outstanding tasks.

## Merge

Extract at the canonical team-kit root, allowing `analysis/T5/` and four NASA source-table folders to merge. Do NOT replace other analysis tracks. Check card links before publishing.

- `analysis/T5/HANDOFF.md` is the authoritative concise scope/limitations and team handoff.
- `analysis/T5/PSI-*/findings.md`: 19 source-linked findings with confidence and caveats.
- `analysis/T5/PSI-*/card.json`: four partial-review cards with explicit unverified field flags.
- `analysis/T5/PSI-*/charts/`: 7 descriptive PNGs (four pre-approved PSI-20 charts, three new).
- `analysis/T5/references.md`, `si_log.md`, `rag_chunks.jsonl`, `data_log.md`: compliance and optional RAG seed.
- `data/experimental_tables/PSI-*/`: original NASA CSV tables unchanged.
- `data/raw/PSI-20/`: original BRE raw pair unchanged.
- `source_reports/`: original BRE Final Report unchanged.
- `supporting_packages/`: already verified Task04C, Task05, PSI10 work kept intact for reference/reproduction.

Run from integrated kit root: `python analysis/T5/scripts/build_t5_summary.py` to regenerate PSI-10/22/23 charts. For BRE use its approved `run_eda.py` with explicit `--raw data/raw/PSI-20/19056A2_data.csv --table "data/experimental_tables/PSI-20/Experimental table/PSI-20_Experimental table_ACME BRE.csv" --out analysis/T5/PSI-20_bre/charts` to regenerate PNGs. Note BRE EDA script also writes short summary artifacts in output, but never changes source data.

## Important limits

1. PSI-22 Test Day 18319 is repeated; the raw sum 230 is not a verified unique-day count.
2. BRE 194/196 discrepancy unresolved and two date differences retained.
3. NASA PSI four card *live version, file size and exact Cite this Investigation UI* not verified. NASA metadata titles/DOI and NASA Science objectives were cross-checked, but partial verification remains clearly marked.
4. The site has not been human-click-tested by this deliverable.
5. Only T5 is covered; T2/T4/T6 and remaining corpora are team-owned gaps.

Do not publish claims of fire risk rankings, calibrated extinction thresholds, model performance or comprehensive NASA raw coverage from these summary tables.
