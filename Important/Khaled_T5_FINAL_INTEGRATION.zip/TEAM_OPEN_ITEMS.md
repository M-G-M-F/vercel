# Team open items — not part of this T5 handoff

The T5 owner delivered **four ACME studies** and a minimally self-contained integration archive. No claim is made that the following other owners' work was done:

| Area | Owner / coordination | Still required |
|---|---|---|
| NASA PSI RAG corpus: PSI-21 (CLD), PSI-60 | Gamal | Supply source-linked corpora; indicate unavailable content without inventing claims |
| NASA PSI RAG corpus: PSI-62, PSI-115, PSI-117, PSI-142 | Unassigned / Mohammed Tamer to allocate | Prepare minimal citation-backed corpus if essential to dashboard, otherwise label as no corpus |
| T2 SAFFIRE findings | Shreif | Provide findings supported by source rows and reports |
| T2 SAFFIRE data tables | Shreif | Include the four tables referenced by his corpus, otherwise remove dangling citations |
| T4 FLEX / CFI findings | Mohammed Tamer / T4 | Provide source-linked analyses and caveats |
| T6 SPICE / SLICE findings | Gamal / T6 | Provide source-linked analyses and caveats |
| Amr's provisional dates and units | Amr | Verify or flag as unconfirmed in cards and tables; no silent correction |
| BRE 194 vs 196 | T5 disclosed; science lead adjudication if possible | Preserve both statement contexts, no false reconciliation |
| BRE two date mismatches | T5 disclosed | Keep original CSV dates visible, link NASA Table 1 comparison; do not alter raw files |
| Live website end-to-end browser testing | Site integrator + human reviewer | Click all cards, chart lightboxes, sources, error states, mobile/desktop, navigation and citations |
| Live PSI version/size and verbatim Cite-this-Investigation | Site integrator or human with PSI browser access | Manually check four dynamic PSI record pages; archived NASA API metadata and static NASA Science were checked only partially |

**Recommendation:** Do not delay the T5 merge for unassigned research. Show missing content as `Not yet analyzed`, never as zero or verified. Do a brief human click-through before the submission.
