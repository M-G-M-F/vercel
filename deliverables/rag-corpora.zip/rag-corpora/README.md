# RAG corpora by dataset

One folder per dataset: `corpus.txt` (UTF-8) or `MISSING_CORPUS.txt`. `manifest.json` records every dataset, its names and
aliases, the JSON and sheet files that list it, its crew, corpus source files, chunk counts, status and conflicts.
Generated 2026-11-15 19:59 UTC by `_tools/export_rag_corpora.py` (in the project: `tools/export_rag_corpora.py`).

## Dataset list
The union of every listing in the project, matched on PSI ID: the kit's NASA metadata (`psi_metadata/*.json`), the pipeline's
`investigations.json`, the dashboard's records, the verified assignment sheet, `RAG/rag-map.json` and the track cards. A name
from the map or the sheet joins a PSI ID only through an explicit alias with stated evidence (`alias_evidence`), e.g.
`"guide": ["*"]` in
the map gives the guide every dataset; it is not a dataset. Folder = PSI ID + NASA acronym (or the map name when NASA lists none);
only characters invalid in folder names become `_`.

## Corpora
| Source | Track | Contributor | Chunks |
| --- | --- | --- | --- |
| `RAG/Morgan_RAG_Corpus_v8/PSI-26_BASS/rag_corpus.txt` | T1 | Amr Morgan | 151 |
| `RAG/Morgan_RAG_Corpus_v8/PSI-25_BASS-II/rag_corpus.txt` | T1 | Amr Morgan | 164 |
| `RAG/SAFFIRE_RAG_Corpora/PSI-98/rag_corpus_psi98.txt` | T2 | T2 (Mohamed Shreif by assignment; the files name no author) | 16 |
| `RAG/SAFFIRE_RAG_Corpora/PSI-99/rag_corpus_psi99.txt` | T2 | T2 (Mohamed Shreif by assignment; the files name no author) | 30 |
| `RAG/SAFFIRE_RAG_Corpora/PSI-100/rag_corpus_psi100.txt` | T2 | T2 (Mohamed Shreif by assignment; the files name no author) | 15 |
| `RAG/Mahmoud.txt` | T3 | Mahmoud Nadeem | 213 |
| `RAG/Tamer.txt` | T4 | Mohammed Tamer | 28 |
| `fif-dashboard/rag/PSI-68_FLEX_II/rag_corpus_flex2.txt` | T4 | Mohammed Tamer | 470 |
| `RAG/Gamal.txt` | T6 | Mohamed Gamal | 220 |
| `RAG/NASA_ACME_RAG_Corpora_By_Dataset/PSI-10_Flame_Design/PSI-10_Flame_Design_RAG_Corpus.txt` | T5 | Khaled Adawi | 15 |
| `RAG/NASA_ACME_RAG_Corpora_By_Dataset/PSI-20_Burning_Rate_Emulator/PSI-20_Burning_Rate_Emulator_RAG_Corpus.txt` | T5 | Khaled Adawi | 18 |
| `RAG/NASA_ACME_RAG_Corpora_By_Dataset/PSI-22_E_FIELD/PSI-22_E_FIELD_RAG_Corpus.txt` | T5 | Khaled Adawi | 15 |
| `RAG/NASA_ACME_RAG_Corpora_By_Dataset/PSI-23_s_Flame/PSI-23_s_Flame_RAG_Corpus.txt` | T5 | Khaled Adawi | 15 |
| `RAG/NASA_ACME_RAG_Corpora_By_Dataset/ACME_Shared/ACME_Shared_RAG_Corpus.txt` | T5 | Khaled Adawi | 53 |
| `RAG/CompleteTamerRAGChunks/microgravity_combustion_complete_rag.jsonl` | T4 | Mohammed Tamer | 2149 |

Mapping rules: T1 v6 files are per dataset (chunks present in both BASS files are shared); SAFFIRE sections by their
`Investigation:` line; T3 by PSI IDs in the header, chunk-ID families, or declared source codes (S1/S4 SAME, S2/S5/S8 SAME-R,
S3/S6/S9-S11 DAFT, S7 both flights); the FLEX pack by its header (FLEX-2 chunks to PSI-68); the complete T4 corpus by each
record's `domain` field cross-checked with its source folder; T6 by its `Investigation:` line.

Chunk text is copied verbatim, each preceded by a `>>>` provenance line. Identical text found in several files is kept once
and every copy is listed. Different texts under the same chunk ID would both be kept and flagged. The superseded T1 v5 pack
(`archive/superseded/RAG/Amr.txt`) is compared chunk by chunk with v6 in the manifest (`superseded_versions`), not exported again.

Totals: 3572 source chunks, 28 identical copies merged, 3544 unique,
103 shared across datasets, 0 unmapped, 13 conflicts recorded (see manifest).
Status: `exported` has chunks only about this dataset; `shared` only chunks shared with others; `missing` none.

| Folder | PSI ID | Names | Status | Chunks |
| --- | --- | --- | --- | --- |
| `PSI-10 ACME_Flame Design/` | PSI-10 | ACME/Flame Design, ACME Flame Design, ACME-FLAME-DESIGN | exported | 68 |
| `PSI-20 ACME BRE/` | PSI-20 | ACME BRE, ACME-BRE | exported | 71 |
| `PSI-21 ACME CLD Flame/` | PSI-21 | ACME CLD Flame, ACME CLD, ACME-CLD | missing | 0 |
| `PSI-22 ACME E-FIELD Flames/` | PSI-22 | ACME E-FIELD Flames, ACME-E-FIELD | exported | 68 |
| `PSI-23 ACME s-Flame/` | PSI-23 | ACME s-Flame, ACME S-Flames, ACME-S-FLAME | exported | 68 |
| `PSI-25 BASS-II/` | PSI-25 | BASS-II | exported | 164 |
| `PSI-26 BASS/` | PSI-26 | BASS | exported | 151 |
| `PSI-39 CFI/` | PSI-39 | CFI | exported | 277 |
| `PSI-47 DAFT _ DAFT-2/` | PSI-47 | DAFT / DAFT-2, DAFT and DAFT-2, DAFT | exported | 28 |
| `PSI-62/` | PSI-62 | Concurrent flame-spread modeling vs BASS (ground) | missing | 0 |
| `PSI-68 FLEX-2/` | PSI-68 | FLEX-2, FLEX-II | exported | 626 |
| `PSI-69 FLEX/` | PSI-69 | FLEX | exported | 461 |
| `PSI-98 SAFFIRE-I/` | PSI-98 | SAFFIRE-I | exported | 16 |
| `PSI-99 SAFFIRE-II/` | PSI-99 | SAFFIRE-II | exported | 30 |
| `PSI-100 SAFFIRE-III/` | PSI-100 | SAFFIRE-III | exported | 15 |
| `PSI-101 SAME-R/` | PSI-101 | SAME-R | exported | 148 |
| `PSI-102 SAME/` | PSI-102 | SAME | exported | 71 |
| `PSI-106 SLICE/` | PSI-106 | SLICE | exported | 51 |
| `PSI-107 SPICE/` | PSI-107 | SPICE | exported | 169 |
| `PSI-115/` | PSI-115 | SAME smoke-aerosol modeling (ground) | missing | 0 |
| `PSI-117/` | PSI-117 | Cool-flame CFD using FLEX data (ground) | missing | 0 |
| `PSI-142/` | PSI-142 | Counterflow cool-flame transitions (ground) | missing | 0 |
| `PSI-159 ACME CFI-G/` | PSI-159 | ACME CFI-G, ACME-CFI-G | exported | 1300 |
